<!-- title: Machine Learning -->
<-- url: https://en.wikipedia.org/wiki/Machine_learning -->

# Machine learning

Study of algorithms that improve automatically through experience

.mw-parser-output .hatnote{font-style:italic}.mw-parser-output div.hatnote{padding-left:1.6em;margin-bottom:0.5em}.mw-parser-output .hatnote i{font-style:normal}.mw-parser-output .hatnote+link+.hatnote{margin-top:-0.5em}@media print{body.ns-0 .mw-parser-output .hatnote{display:none!important}}

.mw-parser-output .hlist dl,.mw-parser-output .hlist ol,.mw-parser-output .hlist ul{margin:0;padding:0}.mw-parser-output .hlist dd,.mw-parser-output .hlist dt,.mw-parser-output .hlist li{margin:0;display:inline}.mw-parser-output .hlist.inline,.mw-parser-output .hlist.inline dl,.mw-parser-output .hlist.inline ol,.mw-parser-output .hlist.inline ul,.mw-parser-output .hlist dl dl,.mw-parser-output .hlist dl ol,.mw-parser-output .hlist dl ul,.mw-parser-output .hlist ol dl,.mw-parser-output .hlist ol ol,.mw-parser-output .hlist ol ul,.mw-parser-output .hlist ul dl,.mw-parser-output .hlist ul ol,.mw-parser-output .hlist ul ul{display:inline}.mw-parser-output .hlist .mw-empty-li{display:none}.mw-parser-output .hlist dt::after{content:": "}.mw-parser-output .hlist dd::after,.mw-parser-output .hlist li::after{content:" · ";font-weight:bold}.mw-parser-output .hlist dd:last-child::after,.mw-parser-output .hlist dt:last-child::after,.mw-parser-output .hlist li:last-child::after{content:none}.mw-parser-output .hlist dd dd:first-child::before,.mw-parser-output .hlist dd dt:first-child::before,.mw-parser-output .hlist dd li:first-child::before,.mw-parser-output .hlist dt dd:first-child::before,.mw-parser-output .hlist dt dt:first-child::before,.mw-parser-output .hlist dt li:first-child::before,.mw-parser-output .hlist li dd:first-child::before,.mw-parser-output .hlist li dt:first-child::before,.mw-parser-output .hlist li li:first-child::before{content:" (";font-weight:normal}.mw-parser-output .hlist dd dd:last-child::after,.mw-parser-output .hlist dd dt:last-child::after,.mw-parser-output .hlist dd li:last-child::after,.mw-parser-output .hlist dt dd:last-child::after,.mw-parser-output .hlist dt dt:last-child::after,.mw-parser-output .hlist dt li:last-child::after,.mw-parser-output .hlist li dd:last-child::after,.mw-parser-output .hlist li dt:last-child::after,.mw-parser-output .hlist li li:last-child::after{content:")";font-weight:normal}.mw-parser-output .hlist ol{counter-reset:listitem}.mw-parser-output .hlist ol>li{counter-increment:listitem}.mw-parser-output .hlist ol>li::before{content:" "counter(listitem)"\a0 "}.mw-parser-output .hlist dd ol>li:first-child::before,.mw-parser-output .hlist dt ol>li:first-child::before,.mw-parser-output .hlist li ol>li:first-child::before{content:" ("counter(listitem)"\a0 "}

.mw-parser-output .sidebar{width:22em;float:right;clear:right;margin:0.5em 0 1em 1em;background:var(--background-color-neutral-subtle,#f8f9fa);border:1px solid var(--border-color-base,#a2a9b1);padding:0.2em;text-align:center;line-height:1.4em;font-size:88%;border-collapse:collapse;display:table}body.skin-minerva .mw-parser-output .sidebar{display:table!important;float:right!important;margin:0.5em 0 1em 1em!important}.mw-parser-output .sidebar-subgroup{width:100%;margin:0;border-spacing:0}.mw-parser-output .sidebar-left{float:left;clear:left;margin:0.5em 1em 1em 0}.mw-parser-output .sidebar-none{float:none;clear:both;margin:0.5em 1em 1em 0}.mw-parser-output .sidebar-outer-title{padding:0 0.4em 0.2em;font-size:125%;line-height:1.2em;font-weight:bold}.mw-parser-output .sidebar-top-image{padding:0.4em}.mw-parser-output .sidebar-top-caption,.mw-parser-output .sidebar-pretitle-with-top-image,.mw-parser-output .sidebar-caption{padding:0.2em 0.4em 0;line-height:1.2em}.mw-parser-output .sidebar-pretitle{padding:0.4em 0.4em 0;line-height:1.2em}.mw-parser-output .sidebar-title,.mw-parser-output .sidebar-title-with-pretitle{padding:0.2em 0.8em;font-size:145%;line-height:1.2em}.mw-parser-output .sidebar-title-with-pretitle{padding:0.1em 0.4em}.mw-parser-output .sidebar-image{padding:0.2em 0.4em 0.4em}.mw-parser-output .sidebar-heading{padding:0.1em 0.4em}.mw-parser-output .sidebar-content{padding:0 0.5em 0.4em}.mw-parser-output .sidebar-content-with-subgroup{padding:0.1em 0.4em 0.2em}.mw-parser-output .sidebar-above,.mw-parser-output .sidebar-below{padding:0.3em 0.8em;font-weight:bold}.mw-parser-output .sidebar-collapse .sidebar-above,.mw-parser-output .sidebar-collapse .sidebar-below{border-top:1px solid #aaa;border-bottom:1px solid #aaa}.mw-parser-output .sidebar-navbar{text-align:right;font-size:115%;padding:0 0.4em 0.4em}.mw-parser-output .sidebar-list-title{padding:0 0.4em;text-align:left;font-weight:bold;line-height:1.6em;font-size:105%}.mw-parser-output .sidebar-list-title-c{padding:0 0.4em;text-align:center;margin:0 3.3em}@media(max-width:640px){body.mediawiki .mw-parser-output .sidebar{width:100%!important;clear:both;float:none!important;margin-left:0!important;margin-right:0!important}}body.skin--responsive .mw-parser-output .sidebar a>img{max-width:none!important}@media screen{html.skin-theme-clientpref-night .mw-parser-output .sidebar:not(.notheme) .sidebar-list-title,html.skin-theme-clientpref-night .mw-parser-output .sidebar:not(.notheme) .sidebar-title-with-pretitle{background:transparent!important}html.skin-theme-clientpref-night .mw-parser-output .sidebar:not(.notheme) .sidebar-title-with-pretitle a{color:var(--color-progressive)!important}}@media screen and (prefers-color-scheme:dark){html.skin-theme-clientpref-os .mw-parser-output .sidebar:not(.notheme) .sidebar-list-title,html.skin-theme-clientpref-os .mw-parser-output .sidebar:not(.notheme) .sidebar-title-with-pretitle{background:transparent!important}html.skin-theme-clientpref-os .mw-parser-output .sidebar:not(.notheme) .sidebar-title-with-pretitle a{color:var(--color-progressive)!important}}@media print{body.ns-0 .mw-parser-output .sidebar{display:none!important}}

.mw-parser-output .nobold{font-weight:normal}

**Machine learning** (**ML**) is a [field of study](/wiki/Field_of_study) in [artificial intelligence](/wiki/Artificial_intelligence) concerned with the development and study of [statistical algorithms](/wiki/Computational_statistics) that can learn from [data](/wiki/Data) and [generalise](/wiki/Generalise) to unseen data, and thus perform [tasks](/wiki/Task_(computing)) without explicit [instructions](/wiki/Machine_code). Within a subdiscipline in machine learning, advances in the field of [deep learning](/wiki/Deep_learning) have allowed [neural networks](/wiki/Neural_network_(machine_learning)), a class of statistical algorithms, to surpass many previous machine learning approaches in performance.

ML finds application in many fields, including [natural language processing](/wiki/Natural_language_processing), [computer vision](/wiki/Computer_vision), [speech recognition](/wiki/Speech_recognition), [email filtering](/wiki/Email_filtering), [agriculture](/wiki/Agriculture), and [medicine](/wiki/Medicine). The application of ML to business problems is known as [predictive analytics](/wiki/Predictive_analytics).

[Statistics](/wiki/Statistics) and [mathematical optimisation](/wiki/Mathematical_optimisation) (mathematical programming) methods comprise the foundations of machine learning. [Data mining](/wiki/Data_mining) is a related field of study, focusing on [exploratory data analysis](/wiki/Exploratory_data_analysis) (EDA) via [unsupervised learning](/wiki/Unsupervised_learning).

From a theoretical viewpoint, [probably approximately correct learning](/wiki/Probably_approximately_correct_learning) provides a mathematical and statistical framework for describing machine learning. Most traditional machine learning and deep learning algorithms can be described as [empirical risk minimisation](/wiki/Empirical_risk_minimisation) under this framework.

.mw-parser-output .toclimit-2 .toclevel-1 ul,.mw-parser-output .toclimit-3 .toclevel-2 ul,.mw-parser-output .toclimit-4 .toclevel-3 ul,.mw-parser-output .toclimit-5 .toclevel-4 ul,.mw-parser-output .toclimit-6 .toclevel-5 ul,.mw-parser-output .toclimit-7 .toclevel-6 ul{display:none}

## History

The term *machine learning* was coined in 1959 by [Arthur Samuel](/wiki/Arthur_Samuel_(computer_scientist)), an [IBM](/wiki/IBM) employee and pioneer in the field of [computer gaming](/wiki/Computer_gaming) and [artificial intelligence](/wiki/Artificial_intelligence). The synonym *self-teaching computers* was also used in this time period.

The earliest machine learning program was introduced in the 1950s when [Arthur Samuel](/wiki/Arthur_Samuel_(computer_scientist)) invented a [computer program](/wiki/Computer_program) that calculated the winning chance in checkers for each side, but the history of machine learning roots back to decades of human desire and effort to study human cognitive processes. In 1949, [Canadian](/wiki/Canadians) psychologist [Donald Hebb](/wiki/Donald_O._Hebb) published the book *[The Organization of Behavior](/wiki/Organization_of_Behavior)*, in which he introduced a [theoretical neural structure](/wiki/Hebbian_theory) formed by certain interactions among [nerve cells](/wiki/Nerve_cells). [Hebb's model](/wiki/Hebb%27s_model) of [neurons](/wiki/Neuron) interacting with one another set a groundwork for how AIs and machine learning algorithms work under nodes, or [artificial neurons](/wiki/Artificial_neuron) used by computers to communicate data. Other researchers who have studied human [cognitive systems](/wiki/Cognitive_systems_engineering) contributed to the modern machine learning technologies as well, including logician [Walter Pitts](/wiki/Walter_Pitts) and [Warren McCulloch](/wiki/Warren_Sturgis_McCulloch), who proposed the early mathematical models of neural networks to come up with [algorithms](/wiki/Algorithm) that mirror human thought processes.

By the early 1960s, an experimental "learning machine" with [punched tape](/wiki/Punched_tape) memory, called Cybertron, had been developed by [Raytheon Company](/wiki/Raytheon_Company) to analyse [sonar](/wiki/Sonar) signals, [electrocardiograms](/wiki/Electrocardiography), and speech patterns using rudimentary [reinforcement learning](/wiki/Reinforcement_learning). It was repetitively "trained" by a human operator/teacher to recognise patterns and equipped with a "[goof](/wiki/Goof)" button to cause it to reevaluate incorrect decisions. A representative book on research into machine learning during the 1960s was [Nils Nilsson](/wiki/Nils_John_Nilsson)'s book on Learning Machines, dealing mostly with machine learning for pattern classification. Interest related to pattern recognition continued into the 1970s, as described by Duda and Hart in 1973. In 1981, a report was given on using teaching strategies so that an [artificial neural network](/wiki/Artificial_neural_network) learns to recognise 40 characters (26 letters, 10 digits, and 4 special symbols) from a computer terminal.

[Tom M. Mitchell](/wiki/Tom_M._Mitchell) provided a widely quoted, more formal definition of the algorithms studied in the machine learning field: "A computer program is said to learn from experience *E* with respect to some class of tasks *T* and performance measure *P* if its performance at tasks in *T*, as measured by *P*,  improves with experience *E*." This definition of the tasks in which machine learning is concerned offers a fundamentally [operational definition](/wiki/Operational_definition) rather than defining the field in cognitive terms. This follows [Alan Turing](/wiki/Alan_Turing)'s proposal in his paper "[Computing Machinery and Intelligence](/wiki/Computing_Machinery_and_Intelligence)", in which the question, "Can machines think?", is replaced with the question, "Can machines do what we (as thinking entities) can do?".

Modern-day Machine Learning algorithms are broken into 3 algorithm types: Supervised Learning Algorithms, Unsupervised Learning Algorithms, and Reinforcement Learning Algorithms.

- Current Supervised Learning Algorithms have objectives of classification and regression.
- Current Unsupervised Learning Algorithms have objectives of clustering, dimensionality reduction, and association rule.
- Current Reinforcement Learning Algorithms focus on decisions that must be made with respect to some previous, unknown time and are broken down to either be studies of model-based methods or model-free methods.

In 2014 Ian Goodfellow and others introduced generative adversarial networks (GANs) with realistic data synthesis. By 2016 AlphaGo obtained victory against top human players using reinforcement learning techniques.

## Relationships to other fields

### Artificial intelligence

As a scientific endeavour, machine learning grew out of the quest for [artificial intelligence](/wiki/Artificial_intelligence) (AI). In the early days of AI as an [academic discipline](/wiki/Discipline_(academia)), some researchers were interested in having machines learn from data. They attempted to approach the problem with various symbolic methods, as well as what were then termed "[neural networks](/wiki/Artificial_neural_network)"; these were mostly [perceptrons](/wiki/Perceptron) and [other models](/wiki/ADALINE) that were later found to be reinventions of the [generalised linear models](/wiki/Generalised_linear_model) of statistics. [Probabilistic reasoning](/wiki/Probabilistic_reasoning) was also employed, especially in [automated medical diagnosis](/wiki/Automated_medical_diagnosis).

However, an increasing emphasis on the [logical, knowledge-based approach](/wiki/Symbolic_AI) caused a rift between AI and machine learning. Probabilistic systems were plagued by theoretical and practical problems of data acquisition and representation. By 1980, [expert systems](/wiki/Expert_system) had come to dominate AI, and statistics was out of favour. Work on symbolic/knowledge-based learning did continue within AI, leading to [inductive logic programming](/wiki/Inductive_logic_programming)(ILP), but the more statistical line of research was now outside the field of AI proper, in [pattern recognition](/wiki/Pattern_recognition) and [information retrieval](/wiki/Information_retrieval). Neural networks research had been abandoned by AI and [computer science](/wiki/Computer_science) around the same time. This line, too, was continued outside the AI/CS field, as "[connectionism](/wiki/Connectionism)", by researchers from other disciplines, including [John Hopfield](/wiki/John_Hopfield), [David Rumelhart](/wiki/David_Rumelhart), and [Geoffrey Hinton](/wiki/Geoffrey_Hinton). Their main success came in the mid-1980s with the reinvention of [backpropagation](/wiki/Backpropagation).

Machine learning (ML), reorganised and recognised as its own field, started to flourish in the 1990s. The field changed its goal from achieving artificial intelligence to tackling solvable problems of a practical nature. It shifted focus away from the [symbolic approaches](/wiki/Symbolic_artificial_intelligence) it had inherited from AI, and toward methods and models borrowed from statistics, [fuzzy logic](/wiki/Fuzzy_logic), and [probability theory](/wiki/Probability_theory).

### Data compression

.mw-parser-output .excerpt-hat .mw-editsection-like{font-style:normal}

There is a close connection between machine learning and compression. A system that predicts the [posterior probabilities](/wiki/Posterior_probabilities) of a sequence given its entire history can be used for optimal data compression (by using [arithmetic coding](/wiki/Arithmetic_coding) on the output distribution). Conversely, an optimal compressor can be used for prediction (by finding the symbol that compresses best, given the previous history). This equivalence has been used as a justification for using data compression as a benchmark for "general intelligence".

An alternative view can show compression algorithms implicitly map strings into implicit [feature space vectors](/wiki/Feature_space_vector), and compression-based similarity measures compute similarity within these feature spaces. For each compressor C(.) we define an associated vector space ℵ, such that C(.) maps an input string x, corresponding to the vector norm ||~x||. An exhaustive examination of the feature spaces underlying all compression algorithms is precluded by space; instead, feature vectors chooses to examine three representative lossless compression methods, LZW, LZ77, and PPM.

According to [AIXI](/wiki/AIXI) theory, a connection more directly explained in [Hutter Prize](/wiki/Hutter_Prize), the best possible compression of x is the smallest possible software that generates x. For example, in that model, a zip file's compressed size includes both the zip file and the unzipping software, since you can not unzip it without both, but there may be an even smaller combined form.

Examples of AI-powered audio/video compression software include [NVIDIA Maxine](/wiki/NVIDIA_Maxine), AIVC. Examples of software that can perform AI-powered image compression include [OpenCV](/wiki/OpenCV), [TensorFlow](/wiki/TensorFlow), [MATLAB](/wiki/MATLAB)'s Image Processing Toolbox (IPT) and High-Fidelity Generative Image Compression.

In [unsupervised machine learning](/wiki/Unsupervised_machine_learning), [k-means clustering](/wiki/K-means_clustering) can be utilized to compress data by grouping similar data points into clusters. This technique simplifies handling extensive datasets that lack predefined labels and finds widespread use in fields such as [image compression](/wiki/Image_compression).

Data compression aims to reduce the size of data files, enhancing storage efficiency and speeding up data transmission. K-means clustering, an unsupervised machine learning algorithm, is employed to partition a dataset into a specified number of clusters, k, each represented by the [centroid](/wiki/Centroid) of its points. This process condenses extensive datasets into a more compact set of representative points. Particularly beneficial in [image](/wiki/Image_processing) and [signal processing](/wiki/Signal_processing), k-means clustering aids in data reduction by replacing groups of data points with their centroids, thereby preserving the core information of the original data while significantly decreasing the required storage space.

[Large language models](/wiki/Large_language_model)(LLMs) are also efficient lossless data compressors on some data sets, as demonstrated by

[DeepMind](/wiki/DeepMind)'s research with the Chinchilla 70B model. Developed by DeepMind, Chinchilla 70B effectively compressed data, outperforming conventional methods such as

[Portable Network Graphics](/wiki/Portable_Network_Graphics)(PNG) for images and

[Free Lossless Audio Codec](/wiki/Free_Lossless_Audio_Codec)(FLAC) for audio. It achieved compression of image and audio data to 43.4% and 16.4% of their original sizes, respectively. There is, however, some reason to be concerned that the data set used for testing overlaps the LLM training data set, making it possible that the Chinchilla 70B model is only an efficient compression tool on data it has already been trained on.

### Data mining

Machine learning and [data mining](/wiki/Data_mining) often employ the same methods and overlap significantly, but while machine learning focuses on prediction, based on *known* properties learned from the training data, data mining focuses on the [discovery](/wiki/Discovery_(observation)) of (previously) *unknown* properties in the data (this is the analysis step of [knowledge discovery](/wiki/Knowledge_discovery) in databases). Data mining uses many machine learning methods, but with different goals; on the other hand, machine learning also employs data mining methods as "[unsupervised learning](/wiki/Unsupervised_learning)" or as a preprocessing step to improve learner accuracy. Much of the confusion between these two research communities (which do often have separate conferences and separate journals, [ECML PKDD](/wiki/ECML_PKDD) being a major exception) comes from the basic assumptions they work with: in machine learning, performance is usually evaluated with respect to the ability to *reproduce known* knowledge, while in knowledge discovery and data mining (KDD) the key task is the discovery of previously *unknown* knowledge. Evaluated with respect to known knowledge, an uninformed (unsupervised) method will easily be outperformed by other supervised methods, while in a typical KDD task, supervised methods cannot be used due to the unavailability of training data.[*[citation needed](/wiki/Wikipedia:Citation_needed)*]

Machine learning also has intimate ties to [optimisation](/wiki/Optimisation): Many learning problems are formulated as minimisation of some [loss function](/wiki/Loss_function) on a training set of examples. Loss functions express the discrepancy between the predictions of the model being trained and the actual problem instances (for example, in classification, one wants to assign a [label](/wiki/Labeled_data) to instances, and models are trained to correctly predict the preassigned labels of a set of examples).

### Generalization

Characterizing the generalisation of various learning algorithms is an active topic of current research, especially for [deep learning](/wiki/Deep_learning) algorithms.

### Statistics

Machine learning and [statistics](/wiki/Statistics) are closely related fields in terms of methods, but distinct in their principal goal: statistics draws population [inferences](/wiki/Statistical_inference) from a [sample](/wiki/Sample_(statistics)), while machine learning finds generalisable predictive patterns.

Conventional statistical analyses require the a priori selection of a model most suitable for the study data set. In addition, only significant or theoretically relevant variables based on previous experience are included for analysis. In contrast, machine learning is not built on a pre-structured model; rather, the data shape the model by detecting underlying patterns. The more variables (input) used to train the model, the more accurate the ultimate model will be.

[Leo Breiman](/wiki/Leo_Breiman) distinguished two statistical modelling paradigms: data model and algorithmic model, wherein "algorithmic model" means more or less the machine learning algorithms like [Random Forest](/wiki/Random_forest).

Some statisticians have adopted methods from machine learning, leading to a combined field that they call *statistical learning*.

### Statistical physics

Analytical and computational techniques derived from deep-rooted physics of disordered systems can be extended to large-scale problems, including machine learning, e.g., to analyse the weight space of [deep neural networks](/wiki/Deep_neural_network). Statistical physics is thus finding applications in the area of [medical diagnostics](/wiki/Medical_diagnostics).

## Theory

A core objective of a learner is to generalise from its experience. Generalization in this context is the ability of a learning machine to perform accurately on new, unseen examples/tasks after having experienced a learning data set. The training examples come from some generally unknown probability distribution (considered representative of the space of occurrences) and the learner has to build a general model about this space that enables it to produce sufficiently accurate predictions in new cases.

The computational analysis of machine learning algorithms and their performance is a branch of [theoretical computer science](/wiki/Theoretical_computer_science) known as [computational learning theory](/wiki/Computational_learning_theory) via the [probably approximately correct learning](/wiki/Probably_approximately_correct_learning)  model. Because training sets are finite and the future is uncertain, learning theory usually does not yield guarantees of the performance of algorithms. Instead, probabilistic bounds on the performance are quite common. The [bias–variance decomposition](/wiki/Bias%E2%80%93variance_decomposition) is one way to quantify generalisation [error](/wiki/Errors_and_residuals).

For the best performance in the context of generalisation, the complexity of the hypothesis should match the complexity of the function underlying the data. If the hypothesis is less complex than the function, then the model has underfitted the data. If the complexity of the model is increased in response, then the training error decreases. But if the hypothesis is too complex, then the model is subject to [overfitting](/wiki/Overfitting) and generalisation will be poorer.

In addition to performance bounds, learning theorists study the time complexity and feasibility of learning. In computational learning theory, a computation is considered feasible if it can be done in [polynomial time](/wiki/Time_complexity#Polynomial_time). There are two kinds of [time complexity](/wiki/Time_complexity) results: Positive results show that a certain class of functions can be learned in polynomial time. Negative results show that certain classes cannot be learned in polynomial time.

## Approaches

Machine learning approaches are traditionally divided into three broad categories, which correspond to learning paradigms, depending on the nature of the "signal" or "feedback" available to the learning system:

- [Supervised learning](/wiki/Supervised_learning): The computer is presented with example inputs and their desired outputs, given by a "teacher", and the goal is to learn a general rule that [maps](/wiki/Map_(mathematics)) inputs to outputs.
- [Unsupervised learning](/wiki/Unsupervised_learning): No labels are given to the learning algorithm, leaving it on its own to find structure in its input. Unsupervised learning can be a goal in itself (discovering hidden patterns in data) or a means towards an end ([feature learning](/wiki/Feature_learning)).
- [Reinforcement learning](/wiki/Reinforcement_learning): A computer program interacts with a dynamic environment in which it must perform a certain goal (such as [driving a vehicle](/wiki/Autonomous_car) or playing a game against an opponent). As it navigates its problem space, the program is provided feedback that's analogous to rewards, which it tries to maximise.

Although each algorithm has advantages and limitations, no single algorithm works for all problems.

### Supervised learning

Supervised learning algorithms build a mathematical model of a set of data that contains both the inputs and the desired outputs. The data, known as [training data](/wiki/Training_data), consists of a set of training examples. Each training example has one or more inputs and the desired output, also known as a supervisory signal. In the mathematical model, each training example is represented by an [array](/wiki/Array_data_structure) or vector, sometimes called a [feature vector](/wiki/Feature_vector), and the training data is represented by a [matrix](/wiki/Matrix_(mathematics)). Through [iterative optimisation](/wiki/Mathematical_optimization#Computational_optimization_techniques) of an [objective function](/wiki/Loss_function), supervised learning algorithms learn a function that can be used to predict the output associated with new inputs. An optimal function allows the algorithm to correctly determine the output for inputs that were not a part of the training data. An algorithm that improves the accuracy of its outputs or predictions over time is said to have learned to perform that task.

Types of supervised-learning algorithms include [active learning](/wiki/Active_learning_(machine_learning)), [classification](/wiki/Statistical_classification) and [regression](/wiki/Regression_analysis). Classification algorithms are used when the outputs are restricted to a limited set of values, while regression algorithms are used when the outputs can take any numerical value within a range. For example, in a classification algorithm that filters emails, the input is an incoming email, and the output is the folder in which to file the email. In contrast, regression is used for tasks such as predicting a person's height based on factors like age and genetics or forecasting future temperatures based on historical data.

[Similarity learning](/wiki/Similarity_learning) is an area of supervised machine learning closely related to regression and classification, but the goal is to learn from examples using a similarity function that measures how similar or related two objects are. It has applications in [ranking](/wiki/Ranking), [recommendation systems](/wiki/Recommender_system), visual identity tracking, face verification, and speaker verification.

### Unsupervised learning

Unsupervised learning algorithms find structures in data that has not been labelled, classified or categorised. Instead of responding to feedback, unsupervised learning algorithms identify commonalities in the data and react based on the presence or absence of such commonalities in each new piece of data. Central applications of unsupervised machine learning include clustering, [dimensionality reduction](/wiki/Dimensionality_reduction), and [density estimation](/wiki/Density_estimation).

Cluster analysis is the assignment of a set of observations into subsets (called *clusters*) so that observations within the same cluster are similar according to one or more predesignated criteria, while observations drawn from different clusters are dissimilar. Different clustering techniques make different assumptions on the structure of the data, often defined by some *similarity metric* and evaluated, for example, by *internal compactness*, or the similarity between members of the same cluster, and *separation*, the difference between clusters. Other methods are based on *estimated density* and *graph connectivity*.

A special type of unsupervised learning called, [self-supervised learning](/wiki/Self-supervised_learning) involves training a model by generating the supervisory signal from the data itself.

### Semi-supervised learning

Semi-supervised learning falls between [unsupervised learning](/wiki/Unsupervised_learning) (without any labelled training data) and [supervised learning](/wiki/Supervised_learning) (with completely labelled training data). Some of the training examples are missing training labels, yet many machine-learning researchers have found that unlabelled data, when used in conjunction with a small amount of labelled data, can produce a considerable improvement in learning accuracy.

In [weakly supervised learning](/wiki/Weak_supervision), the training labels are noisy, limited, or imprecise; however, these labels are often cheaper to obtain, resulting in larger effective training sets.

### Reinforcement learning

Reinforcement learning is an area of machine learning concerned with how [software agents](/wiki/Software_agent) ought to take [actions](/wiki/Action_selection) in an environment to maximise some notion of cumulative reward. Due to its generality, the field is studied in many other disciplines, such as [game theory](/wiki/Game_theory), [control theory](/wiki/Control_theory), [operations research](/wiki/Operations_research), [information theory](/wiki/Information_theory), [simulation-based optimisation](/wiki/Simulation-based_optimisation), [multi-agent systems](/wiki/Multi-agent_system), [swarm intelligence](/wiki/Swarm_intelligence), [statistics](/wiki/Statistics) and [genetic algorithms](/wiki/Genetic_algorithm). In reinforcement learning, the environment is typically represented as a [Markov decision process](/wiki/Markov_decision_process) (MDP). Many reinforcement learning algorithms use [dynamic programming](/wiki/Dynamic_programming) techniques. Reinforcement learning algorithms do not assume knowledge of an exact mathematical model of the MDP and are used when exact models are infeasible. Reinforcement learning algorithms are used in autonomous vehicles or in learning to play a game against a human opponent.

### Dimensionality reduction

[Dimensionality reduction](/wiki/Dimensionality_reduction) is a process of reducing the number of random variables under consideration by obtaining a set of principal variables. In other words, it is a process of reducing the dimension of the [feature](/wiki/Feature_(machine_learning)) set, also called the "number of features". Most of the dimensionality reduction techniques can be considered as either feature elimination or [extraction](/wiki/Feature_extraction). One of the popular methods of dimensionality reduction is [principal component analysis](/wiki/Principal_component_analysis) (PCA). PCA involves changing higher-dimensional data (e.g., 3D) to a smaller space (e.g., 2D).
The [manifold hypothesis](/wiki/Manifold_hypothesis) proposes that high-dimensional data sets lie along low-dimensional [manifolds](/wiki/Manifold), and many dimensionality reduction techniques make this assumption, leading to the areas of [manifold learning](/wiki/Manifold_learning) and [manifold regularisation](/wiki/Manifold_regularisation).

### Other types

Other approaches have been developed which do not fit neatly into this three-fold categorisation, and sometimes more than one is used by the same machine learning system. For example, [topic modelling](/wiki/Topic_model), [meta-learning](/wiki/Meta-learning_(computer_science)).

#### Self-learning

Self-learning, as a machine learning paradigm, was introduced in 1982 along with a neural network capable of self-learning, named *crossbar adaptive array* (CAA). It gives a solution to the problem learning without any external reward, by introducing emotion as an internal reward. Emotion is used as a state evaluation of a self-learning agent. The CAA self-learning algorithm computes, in a crossbar fashion, both decisions about actions and emotions (feelings) about consequence situations. The system is driven by the interaction between cognition and emotion.
The self-learning algorithm updates a memory matrix W =||w(a,s)|| such that in each iteration executes the following machine learning routine:

1. in situation *s* act *a*
2. receive a consequence situation *s*'
3. compute emotion of being in the consequence situation *v(s')*
4. update crossbar memory  *w'(a,s) = w(a,s) + v(s')*

It is a system with only one input, situation, and only one output, action (or behaviour) a. There is neither a separate reinforcement input nor an advice input from the environment. The backpropagated value (secondary reinforcement) is the emotion toward the consequence situation. The CAA exists in two environments, one is the behavioural environment where it behaves, and the other is the genetic environment, wherefrom it initially and only once receives initial emotions about situations to be encountered in the behavioural environment. After receiving the genome (species) vector from the genetic environment, the CAA learns a goal-seeking behaviour in an environment that contains both desirable and undesirable situations.

#### Feature learning

Several learning algorithms aim at discovering better representations of the inputs provided during training. Classic examples include [principal component analysis](/wiki/Principal_component_analysis) and cluster analysis. Feature learning algorithms, also called representation learning algorithms, often attempt to preserve the information in their input but also transform it in a way that makes it useful, often as a pre-processing step before performing classification or predictions. This technique allows reconstruction of the inputs coming from the unknown data-generating distribution, while not being necessarily faithful to configurations that are implausible under that distribution. This replaces manual [feature engineering](/wiki/Feature_engineering), and allows a machine to both learn the features and use them to perform a specific task.

Feature learning can be either supervised or unsupervised. In supervised feature learning, features are learned using labelled input data. Examples include [artificial neural networks](/wiki/Artificial_neural_network), [multilayer perceptrons](/wiki/Multilayer_perceptron), and supervised [dictionary learning](/wiki/Dictionary_learning). In unsupervised feature learning, features are learned with unlabelled input data.  Examples include dictionary learning, [independent component analysis](/wiki/Independent_component_analysis), [autoencoders](/wiki/Autoencoder), [matrix factorisation](/wiki/Matrix_decomposition) and various forms of [clustering](/wiki/Cluster_analysis).

[Manifold learning](/wiki/Manifold_learning) algorithms attempt to do so under the constraint that the learned representation is low-dimensional. [Sparse coding](/wiki/Sparse_coding) algorithms attempt to do so under the constraint that the learned representation is sparse, meaning that the mathematical model has many zeros. [Multilinear subspace learning](/wiki/Multilinear_subspace_learning) algorithms aim to learn low-dimensional representations directly from [tensor](/wiki/Tensor) representations for multidimensional data, without reshaping them into higher-dimensional vectors. [Deep learning](/wiki/Deep_learning) algorithms discover multiple levels of representation, or a hierarchy of features, with higher-level, more abstract features defined in terms of (or generating) lower-level features. It has been argued that an intelligent machine learns a representation that disentangles the underlying factors of variation that explain the observed data.

Feature learning is motivated by the fact that machine learning tasks such as classification often require input that is mathematically and computationally convenient to process. However, real-world data such as images, video, and sensory data have not yielded attempts to algorithmically define specific features. An alternative is to discover such features or representations through examination, without relying on explicit algorithms.

#### Sparse dictionary learning

Sparse dictionary learning is a feature learning method where a training example is represented as a linear combination of [basis functions](/wiki/Basis_function) and assumed to be a [sparse matrix](/wiki/Sparse_matrix). The method is [strongly NP-hard](/wiki/Strongly_NP-hard) and difficult to solve approximately. A popular [heuristic](/wiki/Heuristic) method for sparse dictionary learning is the [*k*-SVD](/wiki/K-SVD) algorithm. Sparse dictionary learning has been applied in several contexts. In classification, the problem is to determine the class to which a previously unseen training example belongs. For a dictionary where each class has already been built, a new training example is associated with the class that is best sparsely represented by the corresponding dictionary. Sparse dictionary learning has also been applied in [image denoising](/wiki/Image_denoising). The key idea is that a clean image patch can be sparsely represented by an image dictionary, but the noise cannot.

#### Anomaly detection

In [data mining](/wiki/Data_mining), anomaly detection, also known as outlier detection, is the identification of rare items, events or observations that raise suspicions by differing significantly from the majority of the data. Typically, the anomalous items represent an issue such as [bank fraud](/wiki/Bank_fraud), a structural defect, medical problems or errors in a text. Anomalies are referred to as [outliers](/wiki/Outlier), novelties, noise, deviations and exceptions.

In particular, in the context of abuse and network intrusion detection, the interesting objects are often not rare, but unexpected bursts of inactivity. This pattern does not adhere to the common statistical definition of an outlier as a rare object. Many outlier detection methods (in particular, unsupervised algorithms) will fail on such data unless aggregated appropriately. Instead, a cluster analysis algorithm may be able to detect the micro-clusters formed by these patterns.

Three broad categories of anomaly detection techniques exist. Unsupervised anomaly detection techniques detect anomalies in an unlabelled test data set under the assumption that the majority of the instances in the data set are normal, by looking for instances that seem to fit the least to the remainder of the data set. Supervised anomaly detection techniques require a data set that has been labelled as "normal" and "abnormal" and involves training a classifier (the key difference from many other statistical classification problems is the inherently unbalanced nature of outlier detection). Semi-supervised anomaly detection techniques construct a model representing normal behaviour from a given normal training data set and then test the likelihood of a test instance being generated by the model.

#### Robot learning

[Robot learning](/wiki/Robot_learning) is inspired by a multitude of machine learning methods, starting from supervised learning, reinforcement learning, and finally [meta-learning](/wiki/Meta-learning_(computer_science)) (e.g. MAML).

#### Association rules

Association rule learning is a [rule-based machine learning](/wiki/Rule-based_machine_learning) method for discovering relationships between variables in large databases. It is intended to identify strong rules discovered in databases using some measure of "interestingness".

Rule-based machine learning is a general term for any machine learning method that identifies, learns, or evolves "rules" to store, manipulate or apply knowledge. The defining characteristic of a rule-based machine learning algorithm is the identification and utilisation of a set of relational rules that collectively represent the knowledge captured by the system. This is in contrast to other machine learning algorithms that commonly identify a singular model that can be universally applied to any instance in order to make a prediction. Rule-based machine learning approaches include [learning classifier systems](/wiki/Learning_classifier_system), association rule learning, and [artificial immune systems](/wiki/Artificial_immune_system).

Based on the concept of strong rules, [Rakesh Agrawal](/wiki/Rakesh_Agrawal_(computer_scientist)), [Tomasz Imieliński](/wiki/Tomasz_Imieli%C5%84ski) and Arun Swami introduced association rules for discovering regularities between products in large-scale transaction data recorded by [point-of-sale](/wiki/Point-of-sale) (POS) systems in supermarkets. For example, the rule  found in the sales data of a supermarket would indicate that if a customer buys onions and potatoes together, they are likely to also buy hamburger meat. Such information can be used as the basis for decisions about marketing activities such as promotional [pricing](/wiki/Pricing) or [product placements](/wiki/Product_placement). In addition to [market basket analysis](/wiki/Market_basket_analysis), association rules are employed today in application areas including [Web usage mining](/wiki/Web_usage_mining), [intrusion detection](/wiki/Intrusion_detection), [continuous production](/wiki/Continuous_production), and [bioinformatics](/wiki/Bioinformatics). In contrast with [sequence mining](/wiki/Sequence_mining), association rule learning typically does not consider the order of items either within a transaction or across transactions.

[Learning classifier systems](/wiki/Learning_classifier_system) (LCS) are a family of rule-based machine learning algorithms that combine a discovery component, typically a [genetic algorithm](/wiki/Genetic_algorithm), with a learning component, performing either [supervised learning](/wiki/Supervised_learning), [reinforcement learning](/wiki/Reinforcement_learning), or [unsupervised learning](/wiki/Unsupervised_learning). They seek to identify a set of context-dependent rules that collectively store and apply knowledge in a [piecewise](/wiki/Piecewise) manner to make predictions.

[Inductive logic programming](/wiki/Inductive_logic_programming) (ILP) is an approach to rule learning using [logic programming](/wiki/Logic_programming) as a uniform representation for input examples, background knowledge, and hypotheses. Given an encoding of the known background knowledge and a set of examples represented as a logical database of facts, an ILP system will derive a hypothesized logic program that [entails](/wiki/Entailment) all positive and no negative examples. [Inductive programming](/wiki/Inductive_programming) is a related field that considers any kind of programming language for representing hypotheses (and not only logic programming), such as [functional programs](/wiki/Functional_programming).

Inductive logic programming is particularly useful in [bioinformatics](/wiki/Bioinformatics) and [natural language processing](/wiki/Natural_language_processing). [Gordon Plotkin](/wiki/Gordon_Plotkin) and [Ehud Shapiro](/wiki/Ehud_Shapiro) laid the initial theoretical foundation for inductive machine learning in a logical setting. Shapiro built their first implementation (Model Inference System) in 1981: a [Prolog](/wiki/Prolog) program that inductively inferred logic programs from positive and negative examples. The term *inductive* here refers to [philosophical](/wiki/Inductive_reasoning) induction, suggesting a theory to explain observed facts, rather than [mathematical induction](/wiki/Mathematical_induction), proving a property for all members of a well-ordered set.

## Models

A **.mw-parser-output .vanchor>:target~.vanchor-text{background-color:#b1d2ff}@media screen{html.skin-theme-clientpref-night .mw-parser-output .vanchor>:target~.vanchor-text{background-color:#0f4dc9}}@media screen and (prefers-color-scheme:dark){html.skin-theme-clientpref-os .mw-parser-output .vanchor>:target~.vanchor-text{background-color:#0f4dc9}}machine learning model** is a type of [mathematical model](/wiki/Mathematical_model) that, once "trained" on a given dataset, can be used to make predictions or classifications on new data. During training, a learning algorithm iteratively adjusts the model's internal parameters to minimise errors in its predictions. By extension, the term "model" can refer to several levels of specificity, from a general class of models and their associated learning algorithms to a fully trained model with all its internal parameters tuned.

Various types of models have been used and researched for machine learning systems, picking the best model for a task is called [model selection](/wiki/Model_selection).

### Artificial neural networks

Artificial neural networks (ANNs), or [connectionist](/wiki/Connectionism) systems, are computing systems vaguely inspired by the [biological neural networks](/wiki/Biological_neural_network) that constitute animal [brains](/wiki/Brain). Such systems "learn" to perform tasks by considering examples, generally without being programmed with any task-specific rules.

An ANN is a model based on a collection of connected units or nodes called "[artificial neurons](/wiki/Artificial_neuron)", which loosely model the [neurons](/wiki/Neuron) in a biological brain. Each connection, like the [synapses](/wiki/Synapse) in a biological brain, can transmit information, a "signal", from one artificial neuron to another. An artificial neuron that receives a signal can process it and then signal additional artificial neurons connected to it. In common ANN implementations, the signal at a connection between artificial neurons is a [real number](/wiki/Real_number), and the output of each artificial neuron is computed by some non-linear function of the sum of its inputs. The connections between artificial neurons are called "edges". Artificial neurons and edges typically have a [weight](/wiki/Weight_(mathematics)) that adjusts as learning proceeds. The weight increases or decreases the strength of the signal at a connection. Artificial neurons may have a threshold such that the signal is only sent if the aggregate signal crosses that threshold. Typically, artificial neurons are aggregated into layers. Different layers may perform different kinds of transformations on their inputs. Signals travel from the first layer (the input layer) to the last layer (the output layer), possibly after traversing the layers multiple times.

The original goal of the ANN approach was to solve problems in the same way that a [human brain](/wiki/Human_brain) would. However, over time, attention moved to performing specific tasks, leading to deviations from [biology](/wiki/Biology). Artificial neural networks have been used on a variety of tasks, including [computer vision](/wiki/Computer_vision), [speech recognition](/wiki/Speech_recognition), [machine translation](/wiki/Machine_translation), [social network](/wiki/Social_network) filtering, [playing board and video games](/wiki/General_game_playing) and [medical diagnosis](/wiki/Medical_diagnosis).

[Deep learning](/wiki/Deep_learning) consists of multiple hidden layers in an artificial neural network. This approach tries to model the way the human brain processes light and sound into vision and hearing. Some successful applications of deep learning are computer vision and speech recognition.

### Decision trees

Decision tree learning uses a [decision tree](/wiki/Decision_tree) as a [predictive model](/wiki/Predictive_modeling) to go from observations about an item (represented in the branches) to conclusions about the item's target value (represented in the leaves). It is one of the predictive modelling approaches used in statistics, data mining, and machine learning. Tree models where the target variable can take a discrete set of values are called classification trees; in these tree structures, [leaves](/wiki/Leaf_node) represent class labels, and branches represent [conjunctions](/wiki/Logical_conjunction) of features that lead to those class labels. Decision trees where the target variable can take continuous values (typically [real numbers](/wiki/Real_numbers)) are called regression trees. In decision analysis, a decision tree can be used to visually and explicitly represent decisions and [decision making](/wiki/Decision_making). In data mining, a decision tree describes data, but the resulting classification tree can be an input for decision-making.

### Random forest regression

[Random forest regression](/wiki/Random_forest) (RFR) falls under the umbrella of decision [tree-based models](/wiki/Tree-based_models). RFR is an ensemble learning method that builds multiple decision trees and averages their predictions to improve accuracy and to avoid overfitting. To build decision trees, RFR uses bootstrapped sampling; for instance, each decision tree is trained on random data from the training set. This random selection of RFR for training enables the model to reduce biased predictions and achieve a higher degree of accuracy. RFR generates independent decision trees, and it can work on single-output data as well as multiple regressor tasks. This makes RFR compatible to be use in various applications.

### Support-vector machines

Support-vector machines (SVMs), also known as support-vector networks, are a set of related [supervised learning](/wiki/Supervised_learning) methods used for classification and regression. Given a set of training examples, each marked as belonging to one of two categories, an SVM training algorithm builds a model that predicts whether a new example falls into one category. An SVM training algorithm is a non-[probabilistic](/wiki/Probabilistic_classification), [binary](/wiki/Binary_classifier), [linear classifier](/wiki/Linear_classifier), although methods such as [Platt scaling](/wiki/Platt_scaling) exist to use SVM in a probabilistic classification setting. In addition to performing linear classification, SVMs can efficiently perform a non-linear classification using what is called the [kernel trick](/wiki/Kernel_trick), implicitly mapping their inputs into high-dimensional feature spaces.

### Regression analysis

Regression analysis encompasses a large variety of statistical methods to estimate the relationship between input variables and their associated features. Its most common form is [linear regression](/wiki/Linear_regression), where a single line is drawn to best fit the given data according to a mathematical criterion such as [ordinary least squares](/wiki/Ordinary_least_squares). The latter is often extended by [regularisation](/wiki/Regularization_(mathematics)) methods to mitigate overfitting and bias, as in [ridge regression](/wiki/Ridge_regression). When dealing with non-linear problems, go-to models include [polynomial regression](/wiki/Polynomial_regression) (for example, used for trendline fitting in Microsoft Excel), [logistic regression](/wiki/Logistic_regression) (often used in [statistical classification](/wiki/Statistical_classification)) or even [kernel regression](/wiki/Kernel_regression), which introduces non-linearity by taking advantage of the [kernel trick](/wiki/Kernel_trick) to implicitly map input variables to higher-dimensional space.

[Multivariate linear regression](/wiki/General_linear_model) extends the concept of linear regression to handle multiple dependent variables simultaneously. This approach estimates the relationships between a set of input variables and several output variables by fitting a [multidimensional](/wiki/Multidimensional_system) linear model. It is particularly useful in scenarios where outputs are interdependent or share underlying patterns, such as predicting multiple economic indicators or reconstructing images, which are inherently multi-dimensional.

### Bayesian networks

A Bayesian network, belief network, or directed acyclic graphical model is a probabilistic [graphical model](/wiki/Graphical_model) that represents a set of [random variables](/wiki/Random_variables) and their [conditional independence](/wiki/Conditional_independence) with a [directed acyclic graph](/wiki/Directed_acyclic_graph) (DAG). For example, a Bayesian network could represent the probabilistic relationships between diseases and symptoms. Given symptoms, the network can be used to compute the probabilities of the presence of various diseases. Efficient algorithms exist that perform [inference](/wiki/Bayesian_inference) and learning. Bayesian networks that model sequences of variables, like [speech signals](/wiki/Speech_recognition) or [protein sequences](/wiki/Peptide_sequence), are called [dynamic Bayesian networks](/wiki/Dynamic_Bayesian_network). Generalisations of Bayesian networks that can represent and solve decision problems under uncertainty are called [influence diagrams](/wiki/Influence_diagram).

### Gaussian processes

A Gaussian process is a [stochastic process](/wiki/Stochastic_process) in which every finite collection of the random variables in the process has a [multivariate normal distribution](/wiki/Multivariate_normal_distribution), and it relies on a pre-defined [covariance function](/wiki/Covariance_function), or kernel, that models how pairs of points relate to each other depending on their locations.

Given a set of observed points, or input–output examples, the distribution of the (unobserved) output of a new point as a function of its input data can be directly computed by looking at the observed points and the covariances between those points and the new, unobserved point.

Gaussian processes are popular surrogate models in [Bayesian optimisation](/wiki/Bayesian_optimisation) used to do [hyperparameter optimisation](/wiki/Hyperparameter_optimisation).

### Genetic algorithms

A genetic algorithm (GA) is a [search algorithm](/wiki/Search_algorithm) and [heuristic](/wiki/Heuristic_(computer_science)) technique that mimics the process of [natural selection](/wiki/Natural_selection), using methods such as [mutation](/wiki/Mutation_(genetic_algorithm)) and [crossover](/wiki/Crossover_(genetic_algorithm)) to generate new [genotypes](/wiki/Chromosome_(genetic_algorithm)) in the hope of finding good solutions to a given problem. In machine learning, genetic algorithms were used in the 1980s and 1990s. Conversely, machine learning techniques have been used to improve the performance of genetic and [evolutionary algorithms](/wiki/Evolutionary_algorithm).

### Belief functions

The theory of belief functions, also referred to as evidence theory or Dempster–Shafer theory, is a general framework for reasoning with uncertainty, with understood connections to other frameworks such as [probability](/wiki/Probability), [possibility](/wiki/Possibility_theory) and  [imprecise probability theories](/wiki/Imprecise_probability). These theoretical frameworks can be thought of as a kind of learner and have some analogous properties of how evidence is combined (e.g.,  Dempster's rule of combination), just like how in a [pmf](/wiki/Probability_mass_function)-based Bayesian approach would combine probabilities. However, there are many caveats to these beliefs functions when compared to Bayesian approaches to incorporate ignorance and [uncertainty quantification](/wiki/Uncertainty_quantification). These belief function approaches that are implemented within the machine learning domain typically leverage a fusion approach of various [ensemble methods](/wiki/Ensemble_methods) to better handle the learner's [decision boundary](/wiki/Decision_boundary), low samples, and ambiguous class issues that standard machine learning approach tend to have difficulty resolving. However, the computational complexity of these algorithms is dependent on the number of propositions (classes), and can lead to a much higher computation time when compared to other machine learning approaches.

### Rule-based models

Rule-based machine learning (RBML) is a branch of machine learning that automatically discovers and learns 'rules' from data. It provides interpretable models, making it useful for decision-making in fields like healthcare, fraud detection, and cybersecurity. Key RBML techniques includes [learning classifier systems](/wiki/Learning_classifier_system), [association rule learning](/wiki/Association_rule_learning), [artificial immune systems](/wiki/Artificial_immune_system), and other similar models. These methods extract patterns from data and evolve rules over time.

### Training models

Typically, machine learning models require a high quantity of reliable data to perform accurate predictions. When training a machine learning model, machine learning engineers need to target and collect a large and representative [sample](/wiki/Sample_(statistics)) of data. Data from the training set can be as varied as a [corpus of text](/wiki/Corpus_of_text), a collection of images, [sensor](/wiki/Sensor) data, and data collected from individual users of a service. [Overfitting](/wiki/Overfitting) is something to watch out for when training a machine learning model. Trained models derived from biased or non-evaluated data can result in skewed or undesired predictions. Biased models may result in detrimental outcomes, thereby furthering the negative impacts on society or objectives. [Algorithmic bias](/wiki/Algorithmic_bias) is a potential result of data not being fully prepared for training. Machine learning ethics is becoming a field of study and, notably, becoming integrated within machine learning engineering teams.

#### Federated learning

Federated learning is an adapted form of [distributed artificial intelligence](/wiki/Distributed_artificial_intelligence) to train machine learning models that decentralises the training process, allowing for users' privacy to be maintained by not needing to send their data to a centralised server. This also increases efficiency by decentralising the training process to many devices. For example, [Gboard](/wiki/Gboard) uses federated machine learning to train search query prediction models on users' mobile phones without having to send individual searches back to [Google](/wiki/Google).

## Applications

There are many applications for machine learning, including:

.mw-parser-output .div-col{margin-top:0.3em;column-width:30em}.mw-parser-output .div-col-small{font-size:90%}.mw-parser-output .div-col-rules{column-rule:1px solid #aaa}.mw-parser-output .div-col dl,.mw-parser-output .div-col ol,.mw-parser-output .div-col ul{margin-top:0}.mw-parser-output .div-col li,.mw-parser-output .div-col dd{page-break-inside:avoid;break-inside:avoid-column}

- [Agriculture](/wiki/Precision_agriculture)
- [Anatomy](/wiki/Computational_anatomy)
- [Adaptive website](/wiki/Adaptive_website)
- [Affective computing](/wiki/Affective_computing)
- [Astronomy](/wiki/Astroinformatics)
- [Automated decision-making](/wiki/Automated_decision-making)
- [Banking](/wiki/Banking)
- [Behaviorism](/wiki/Behaviorism)
- [Bioinformatics](/wiki/Bioinformatics)
- [Brain–machine interfaces](/wiki/Brain%E2%80%93computer_interface)
- [Cheminformatics](/wiki/Cheminformatics)
- [Citizen Science](/wiki/Citizen_Science)
- [Climate Science](/wiki/Climate_Science)
- [Computer networks](/wiki/Network_simulation)
- [Computer vision](/wiki/Computer_vision)
- [Credit-card fraud](/wiki/Credit-card_fraud) detection
- [Data quality](/wiki/Data_quality)
- [DNA sequence](/wiki/DNA_sequence) classification
- [Economics](/wiki/Computational_economics)
- [Financial data analysis](/wiki/Data_analysis)
- [General game playing](/wiki/General_game_playing)
- [Handwriting recognition](/wiki/Handwriting_recognition)
- [Healthcare](/wiki/Artificial_intelligence_in_healthcare)
- [Information retrieval](/wiki/Information_retrieval)
- [Insurance](/wiki/Insurance)
- [Internet fraud](/wiki/Internet_fraud) detection
- [Investment management](/wiki/Investment_management)
- [Knowledge graph embedding](/wiki/Knowledge_graph_embedding)
- [Linguistics](/wiki/Computational_linguistics)
- [Machine learning control](/wiki/Machine_learning_control)
- [Machine perception](/wiki/Machine_perception)
- [Machine translation](/wiki/Machine_translation)
- [Material Engineering](/wiki/Material_Engineering)
- [Marketing](/wiki/Marketing)
- [Medical diagnosis](/wiki/Automated_medical_diagnosis)
- [Natural language processing](/wiki/Natural_language_processing)
- [Natural language understanding](/wiki/Natural-language_understanding)
- [Online advertising](/wiki/Online_advertising)
- [Optimisation](/wiki/Optimisation)
- [Recommender systems](/wiki/Recommender_system)
- [Robot locomotion](/wiki/Robot_locomotion)
- [Search engines](/wiki/Search_engines)
- [Sentiment analysis](/wiki/Sentiment_analysis)
- [Sequence mining](/wiki/Sequence_mining)
- [Software engineering](/wiki/Software_engineering)
- [Speech recognition](/wiki/Speech_recognition)
- [Structural health monitoring](/wiki/Structural_health_monitoring)
- [Syntactic pattern recognition](/wiki/Syntactic_pattern_recognition)
- [Telecommunications](/wiki/Telecommunications)
- [Theorem proving](/wiki/Automated_theorem_proving)
- [Time-series forecasting](/wiki/Time_series)
- [Tomographic reconstruction](/wiki/Tomographic_reconstruction)
- [User behaviour analytics](/wiki/User_behaviour_analytics)

In 2006, the media-services provider [Netflix](/wiki/Netflix) held the first "[Netflix Prize](/wiki/Netflix_Prize)" competition to find a program to better predict user preferences and improve the accuracy of its existing Cinematch movie recommendation algorithm by at least 10%. A joint team made up of researchers from [AT&T Labs](/wiki/AT%26T_Labs)-Research in collaboration with the teams Big Chaos and Pragmatic Theory built an [ensemble model](/wiki/Ensemble_Averaging) to win the Grand Prize in 2009 for $1 million. Shortly after the prize was awarded, Netflix realised that viewers' ratings were not the best indicators of their viewing patterns ("everything is a recommendation") and they changed their recommendation engine accordingly. In 2010, an article in *[The Wall Street Journal](/wiki/The_Wall_Street_Journal)* noted the use of machine learning by Rebellion Research to predict the [2008 financial crisis](/wiki/2008_financial_crisis). In 2012, co-founder of [Sun Microsystems](/wiki/Sun_Microsystems), [Vinod Khosla](/wiki/Vinod_Khosla), predicted that 80% of medical doctors jobs would be lost in the next two decades to automated machine learning medical diagnostic software. In 2014, it was reported that a machine learning algorithm had been applied in the field of art history to study fine art paintings and that it may have revealed previously unrecognised influences among artists. In 2019 [Springer Nature](/wiki/Springer_Nature) published the first research book created using machine learning. In 2020, machine learning technology was used to help make diagnoses and aid researchers in developing a cure for COVID-19. Machine learning was recently applied to predict the pro-environmental behaviour of travellers. Recently, machine learning technology was also applied to optimise smartphone's performance and thermal behaviour based on the user's interaction with the phone. When applied correctly, machine learning algorithms (MLAs) can utilise a wide range of company characteristics to predict stock returns without [overfitting](/wiki/Overfitting). By employing effective feature engineering and combining forecasts, MLAs can generate results that far surpass those obtained from basic linear techniques like [OLS](/wiki/Ordinary_least_squares).

Recent advancements in machine learning have extended into the field of quantum chemistry, where novel algorithms now enable the prediction of solvent effects on chemical reactions, thereby offering new tools for chemists to tailor experimental conditions for optimal outcomes.

Machine Learning is becoming a useful tool to investigate and predict evacuation decision-making in large-scale and small-scale disasters. Different solutions have been tested to predict if and when householders decide to evacuate during wildfires and hurricanes. Other applications have been focusing on pre evacuation decisions in building fires.

## Limitations

Although machine learning has been transformative in some fields, machine-learning programs often fail to deliver expected results. Reasons for this are numerous: lack of (suitable) data, lack of access to the data, data bias, privacy problems, badly chosen tasks and algorithms, wrong tools and people, lack of resources, and evaluation problems.

The "[black box theory](/wiki/Black_box)" poses another yet significant challenge. Black box refers to a situation where the algorithm or the process of producing an output is entirely opaque, meaning that even the coders of the algorithm cannot audit the pattern that the machine extracted from the data. The House of Lords Select Committee, which claimed that such an "intelligence system" that could have a "substantial impact on an individual's life" would not be considered acceptable unless it provided "a full and satisfactory explanation for the decisions" it makes.

In 2018, a self-driving car from [Uber](/wiki/Uber) failed to detect a pedestrian, who was killed after a collision. Attempts to use machine learning in healthcare with the [IBM Watson](/wiki/Watson_(computer)) system failed to deliver even after years of time and billions of dollars invested. Microsoft's [Bing Chat](/wiki/Bing_Chat) chatbot has been reported to produce hostile and offensive response against its users.

Machine learning has been used as a strategy to update the evidence related to a systematic review and increased reviewer burden related to the growth of biomedical literature. While it has improved with training sets, it has not yet developed sufficiently to reduce the workload burden without limiting the necessary sensitivity for the findings research itself.

### Explainability

Explainable AI (XAI), or Interpretable AI, or Explainable Machine Learning (XML), is artificial intelligence (AI) in which humans can understand the decisions or predictions made by the AI. It contrasts with the "black box" concept in machine learning where even its designers cannot explain why an AI arrived at a specific decision. By refining the mental models of users of AI-powered systems and dismantling their misconceptions, XAI promises to help users perform more effectively. XAI may be an implementation of the social right to explanation.

### Overfitting

Settling on a bad, overly complex theory gerrymandered to fit all the past training data is known as overfitting. Many systems attempt to reduce overfitting by rewarding a theory in accordance with how well it fits the data but penalising the theory in accordance with how complex the theory is.

### Other limitations and vulnerabilities

Learners can also be disappointed by "learning the wrong lesson". A toy example is that an image classifier trained only on pictures of brown horses and black cats might conclude that all brown patches are likely to be horses. A real-world example is that, unlike humans, current image classifiers often do not primarily make judgments from the spatial relationship between components of the picture, and they learn relationships between pixels that humans are oblivious to, but that still correlate with images of certain types of real objects. Modifying these patterns on a legitimate image can result in "adversarial" images that the system misclassifies.

Adversarial vulnerabilities can also result in nonlinear systems or from non-pattern perturbations. For some systems, it is possible to change the output by only changing a single adversarially chosen pixel. Machine learning models are often vulnerable to manipulation or evasion via [adversarial machine learning](/wiki/Adversarial_machine_learning).

Researchers have demonstrated how [backdoors](/wiki/Backdoor_(computing)) can be placed undetectably into classifying (e.g., for categories "spam" and "not spam" of posts) machine learning models that are often developed or trained by third parties. Parties can change the classification of any input, including in cases for which a type of [data/software transparency](/wiki/Algorithmic_transparency) is provided, possibly including [white-box access](/wiki/White-box_testing).

## Model assessments

Classification of machine learning models can be validated by accuracy estimation techniques like the [holdout](/wiki/Test_set) method, which splits the data into a training and test set (conventionally 2/3 training set and 1/3 test set designation) and evaluates the performance of the training model on the test set. In comparison, the K-fold-[cross-validation](/wiki/Cross-validation_(statistics)) method randomly partitions the data into K subsets and then K experiments are performed each considering 1 subset for evaluation and the remaining K-1 subsets for training the model. In addition to the holdout and cross-validation methods, [bootstrap](/wiki/Bootstrapping_(statistics)), which samples n instances with replacement from the dataset, can be used to assess model accuracy.

In addition to overall accuracy, investigators frequently report [sensitivity and specificity](/wiki/Sensitivity_and_specificity), meaning true positive rate (TPR) and true negative rate (TNR), respectively. Similarly, investigators sometimes report the [false positive rate](/wiki/False_positive_rate) (FPR) as well as the [false negative rate](/wiki/False_negative_rate) (FNR). However, these rates are ratios that fail to reveal their numerators and denominators. [Receiver operating characteristic](/wiki/Receiver_operating_characteristic) (ROC), along with the accompanying Area Under the ROC Curve (AUC), offer additional tools for classification model assessment. Higher AUC is associated with a better performing model.

## Ethics

The [ethics](/wiki/Ethics) of [artificial intelligence](/wiki/Artificial_intelligence) covers a broad range of topics within AI that are considered to have particular ethical stakes. This includes [algorithmic biases](/wiki/Algorithmic_bias), [fairness](/wiki/Fairness_(machine_learning)), [automated decision-making](/wiki/Automated_decision-making), [accountability](/wiki/Accountability), [privacy](/wiki/Privacy), and [regulation](/wiki/Regulation_of_artificial_intelligence). It also covers various emerging or potential future challenges such as [machine ethics](/wiki/Machine_ethics) (how to make machines that behave ethically), [lethal autonomous weapon systems](/wiki/Lethal_autonomous_weapon), [arms race](/wiki/Artificial_intelligence_arms_race) dynamics, [AI safety](/wiki/AI_safety) and [alignment](/wiki/AI_alignment), [technological unemployment](/wiki/Technological_unemployment), AI-enabled [misinformation](/wiki/Misinformation), how to treat certain AI systems if they have a [moral status](/wiki/Moral_status) (AI welfare and rights), [artificial superintelligence](/wiki/Artificial_superintelligence) and [existential risks](/wiki/Existential_risk_from_artificial_general_intelligence).

Some application areas may also have particularly important ethical implications, like

[healthcare](/wiki/Artificial_intelligence_in_healthcare), education, criminal justice, or the military.

### Bias

Different machine learning approaches can suffer from different data biases. A machine learning system trained specifically on current customers may not be able to predict the needs of new customer groups that are not represented in the training data. When trained on human-made data, machine learning is likely to pick up the constitutional and unconscious biases already present in society.

Systems that are trained on datasets collected with biases may exhibit these biases upon use (algorithmic bias), thus digitising cultural prejudices. For example, in 1988, the UK's [Commission for Racial Equality](/wiki/Commission_for_Racial_Equality) found that [St. George's Medical School](/wiki/St_George%27s,_University_of_London) had been using a computer program trained from data of previous admissions staff and this program had denied nearly 60 candidates who were found to either be women or have non-European-sounding names. Using job hiring data from a firm with racist hiring policies may lead to a machine learning system duplicating the bias by scoring job applicants by similarity to previous successful applicants. Another example includes predictive policing company [Geolitica](/wiki/Geolitica)'s predictive algorithm that resulted in "disproportionately high levels of over-policing in low-income and minority communities" after being trained with historical crime data.

While responsible [collection of data](/wiki/Data_collection) and documentation of algorithmic rules used by a system is considered a critical part of machine learning, some researchers blame the lack of participation and representation of minority populations in the field of AI for machine learning's vulnerability to biases. In fact, according to research carried out by the Computing Research Association in 2021, "female faculty make up just 16.1%" of all faculty members who focus on AI among several universities around the world. Furthermore, among the group of "new U.S. resident AI PhD graduates," 45% identified as white, 22.4% as Asian, 3.2% as Hispanic, and 2.4% as African American, which further demonstrates a lack of diversity in the field of AI.

Language models learned from data have been shown to contain human-like biases. Because human languages contain biases, machines trained on language *[corpora](/wiki/Text_corpus)* will necessarily also learn these biases. In 2016, Microsoft tested [Tay](/wiki/Tay_(chatbot)), a [chatbot](/wiki/Chatbot) that learned from Twitter, and it quickly picked up racist and sexist language.

In an experiment carried out by [ProPublica](/wiki/ProPublica), an [investigative journalism](/wiki/Investigative_journalism) organisation, a machine learning algorithm's insight into the recidivism rates among prisoners falsely flagged "black defendants high risk twice as often as white defendants". In 2015, Google Photos once tagged a couple of black people as gorillas, which caused controversy. The gorilla label was subsequently removed, and in 2023, it still cannot recognise gorillas. Similar issues with recognising non-white people have been found in many other systems.

Because of such challenges, the effective use of machine learning may take longer to be adopted in other domains. Concern for [fairness](/wiki/Fairness_(machine_learning)) in machine learning, that is, reducing bias in machine learning and propelling its use for human good, is increasingly expressed by artificial intelligence scientists, including [Fei-Fei Li](/wiki/Fei-Fei_Li), who said that "[t]here's nothing artificial about AI. It's inspired by people, it's created by people, and—most importantly—it impacts people. It is a powerful tool we are only just beginning to understand, and that is a profound responsibility."

### Financial incentives

There are concerns among health care professionals that these systems might not be designed in the public's interest but as income-generating machines. This is especially true in the United States, where there is a long-standing ethical dilemma of improving health care, but also increasing profits. For example, the algorithms could be designed to provide patients with unnecessary tests or medication in which the algorithm's proprietary owners hold stakes. There is potential for machine learning in health care to provide professionals with an additional tool to diagnose, medicate, and plan recovery paths for patients, but this requires these biases to be mitigated.

## Hardware

Since the 2010s, advances in both machine learning algorithms and computer hardware have led to more efficient methods for training [deep neural networks](/wiki/Deep_neural_network) (a particular narrow subdomain of machine learning) that contain many layers of nonlinear hidden units. By 2019, graphics processing units ([GPUs](/wiki/GPU)), often with AI-specific enhancements, had displaced CPUs as the dominant method of training large-scale commercial cloud AI. [OpenAI](/wiki/OpenAI) estimated the hardware compute used in the largest deep learning projects from [AlexNet](/wiki/AlexNet) (2012) to [AlphaZero](/wiki/AlphaZero) (2017), and found a 300,000-fold increase in the amount of compute required, with a doubling-time trendline of 3.4 months.

### Tensor Processing Units (TPUs)

[Tensor Processing Units (TPUs)](/wiki/Tensor_Processing_Unit) are specialised hardware accelerators developed by [Google](/wiki/Google) specifically for machine learning workloads. Unlike general-purpose [GPUs](/wiki/Graphics_processing_unit) and [FPGAs](/wiki/Field-programmable_gate_array), TPUs are optimised for tensor computations, making them particularly efficient for deep learning tasks such as training and inference. They are widely used in Google Cloud AI services and large-scale machine learning models like Google's DeepMind AlphaFold and large language models. TPUs leverage matrix multiplication units and high-bandwidth memory to accelerate computations while maintaining energy efficiency. Since their introduction in 2016, TPUs have become a key component of AI infrastructure, especially in cloud-based environments.

### Neuromorphic computing

[Neuromorphic computing](/wiki/Neuromorphic_computing) refers to a class of computing systems designed to emulate the structure and functionality of biological neural networks. These systems may be implemented through software-based simulations on conventional hardware or through specialised hardware architectures.

#### Physical neural networks

A [physical neural network](/wiki/Physical_neural_network) is a specific type of neuromorphic hardware that relies on electrically adjustable materials, such as memristors, to emulate the function of [neural synapses](/wiki/Chemical_synapse). The term "physical neural network" highlights the use of physical hardware for computation, as opposed to software-based implementations. It broadly refers to artificial neural networks that use materials with adjustable resistance to replicate neural synapses.

### Embedded machine learning

Embedded machine learning is a sub-field of machine learning where models are deployed on [embedded systems](/wiki/Embedded_systems) with limited computing resources, such as [wearable computers](/wiki/Wearable_computer), [edge devices](/wiki/Edge_device) and [microcontrollers](/wiki/Microcontrollers). Running models directly on these devices eliminates the need to transfer and store data on cloud servers for further processing, thereby reducing the risk of data breaches, privacy leaks and theft of intellectual property, personal data and business secrets. Embedded machine learning can be achieved through various techniques, such as [hardware acceleration](/wiki/Hardware_acceleration), [approximate computing](/wiki/Approximate_computing), and model optimisation. Common optimisation techniques include [pruning](/wiki/Pruning_(artificial_neural_network)), [quantisation](/wiki/Model_compression#Quantization), [knowledge distillation](/wiki/Knowledge_distillation), low-rank factorisation, network architecture search, and parameter sharing.

## Software

[Software suites](/wiki/Software_suite) containing a variety of machine learning algorithms include the following:

### Free and open-source software

- [Caffe](/wiki/Caffe_(software))
- [Deeplearning4j](/wiki/Deeplearning4j)
- [DeepSpeed](/wiki/DeepSpeed)
- [ELKI](/wiki/ELKI)
- [Google JAX](/wiki/Google_JAX)
- [Infer.NET](/wiki/Infer.NET)
- [JASP](/wiki/JASP)
- [Jubatus](/wiki/Jubatus)
- [Keras](/wiki/Keras)
- [Kubeflow](/wiki/Kubeflow)
- [LightGBM](/wiki/LightGBM)
- [Mahout](/wiki/Apache_Mahout)
- [Mallet](/wiki/Mallet_(software_project))
- [Microsoft Cognitive Toolkit](/wiki/Microsoft_Cognitive_Toolkit)
- [ML.NET](/wiki/ML.NET)
- [mlpack](/wiki/Mlpack)
- [MXNet](/wiki/MXNet)
- [OpenNN](/wiki/OpenNN)
- [Orange](/wiki/Orange_(software))
- [pandas (software)](/wiki/Pandas_(software))
- [ROOT](/wiki/ROOT) (TMVA with ROOT)
- [scikit-learn](/wiki/Scikit-learn)
- [Shogun](/wiki/Shogun_(toolbox))
- [Spark MLlib](/wiki/Apache_Spark#MLlib_Machine_Learning_Library)
- [SystemML](/wiki/Apache_SystemML)
- [Theano](/wiki/Theano_(software))
- [TensorFlow](/wiki/TensorFlow)
- [Torch](/wiki/Torch_(machine_learning)) / [PyTorch](/wiki/PyTorch)
- [Weka](/wiki/Weka_(machine_learning)) / [MOA](/wiki/MOA_(Massive_Online_Analysis))
- [XGBoost](/wiki/XGBoost)
- [Yooreeka](/wiki/Yooreeka)

### Proprietary software with free and open-source editions

- [KNIME](/wiki/KNIME)
- [RapidMiner](/wiki/RapidMiner)

### Proprietary software

- [Amazon Machine Learning](/wiki/Amazon_Machine_Learning)
- [Angoss](/wiki/Angoss) KnowledgeSTUDIO
- [Azure Machine Learning](/wiki/Azure_Machine_Learning)
- [IBM Watson Studio](/wiki/IBM_Watson_Studio)
- [Google Cloud Vertex AI](/wiki/Google_Cloud_Platform#Cloud_AI)
- [Google Prediction API](/wiki/Google_APIs)
- [IBM SPSS Modeller](/wiki/SPSS_Modeler)
- [KXEN Modeller](/wiki/KXEN_Inc.)
- [LIONsolver](/wiki/LIONsolver)
- [Mathematica](/wiki/Mathematica)
- [MATLAB](/wiki/MATLAB)
- [Neural Designer](/wiki/Neural_Designer)
- [NeuroSolutions](/wiki/NeuroSolutions)
- [Oracle Data Mining](/wiki/Oracle_Data_Mining)
- [Oracle AI Platform Cloud Service](/wiki/Oracle_Cloud#Platform_as_a_Service_(PaaS))
- [PolyAnalyst](/wiki/PolyAnalyst)
- [RCASE](/wiki/RCASE)
- [SAS Enterprise Miner](/wiki/SAS_(software)#Components)
- [SequenceL](/wiki/SequenceL)
- [Splunk](/wiki/Splunk)
- [STATISTICA](/wiki/STATISTICA) Data Miner

## Journals

- [Journal of Machine Learning Research](/wiki/Journal_of_Machine_Learning_Research)
- [Machine Learning](/wiki/Machine_Learning_(journal))
- [Nature Machine Intelligence](/wiki/Nature_Machine_Intelligence)
- [Neural Computation](/wiki/Neural_Computation_(journal))
- [IEEE Transactions on Pattern Analysis and Machine Intelligence](/wiki/IEEE_Transactions_on_Pattern_Analysis_and_Machine_Intelligence)

## Conferences

- [AAAI Conference on Artificial Intelligence](/wiki/AAAI_Conference_on_Artificial_Intelligence)
- [Association for Computational Linguistics (**ACL**)](/wiki/Association_for_Computational_Linguistics)
- [European Conference on Machine Learning and Principles and Practice of Knowledge Discovery in Databases (**ECML PKDD**)](/wiki/European_Conference_on_Machine_Learning_and_Principles_and_Practice_of_Knowledge_Discovery_in_Databases)
- [International Conference on Computational Intelligence Methods for Bioinformatics and Biostatistics (**CIBB**)](/wiki/International_Conference_on_Computational_Intelligence_Methods_for_Bioinformatics_and_Biostatistics)
- [International Conference on Machine Learning (**ICML**)](/wiki/International_Conference_on_Machine_Learning)
- [International Conference on Learning Representations (**ICLR**)](/wiki/International_Conference_on_Learning_Representations)
- [International Conference on Intelligent Robots and Systems (**IROS**)](/wiki/International_Conference_on_Intelligent_Robots_and_Systems)
- [Conference on Knowledge Discovery and Data Mining (**KDD**)](/wiki/Conference_on_Knowledge_Discovery_and_Data_Mining)
- [Conference on Neural Information Processing Systems (**NeurIPS**)](/wiki/Conference_on_Neural_Information_Processing_Systems)

## See also

- [Automated machine learning](/wiki/Automated_machine_learning) – Process of automating the application of machine learning
- [Big data](/wiki/Big_data) – Extremely large or complex datasets
- [Deep learning](/wiki/Deep_learning) — branch of ML concerned with [artificial neural networks](/wiki/Artificial_neural_network)
- [Differentiable programming](/wiki/Differentiable_programming) – Programming paradigm
- [List of datasets for machine-learning research](/wiki/List_of_datasets_for_machine-learning_research)
- [List of machine learning algorithms](/wiki/Outline_of_machine_learning#Machine_learning_algorithms) and [List of algorithms for machine learning and statistical classification](/wiki/List_of_algorithms#Machine_learning_and_statistical_classification)
- [M-theory (learning framework)](/wiki/M-theory_(learning_framework)) – Framework in machine learning
- [Machine unlearning](/wiki/Machine_unlearning) – Field of study in artificial intelligence
- [Outline of machine learning](/wiki/Outline_of_machine_learning)
- [Solomonoff's theory of inductive inference](/wiki/Solomonoff%27s_theory_of_inductive_inference) – Mathematical theory

## References

.mw-parser-output .reflist{margin-bottom:0.5em;list-style-type:decimal}@media screen{.mw-parser-output .reflist{font-size:90%}}.mw-parser-output .reflist .references{font-size:100%;margin-bottom:0;list-style-type:inherit}.mw-parser-output .reflist-columns-2{column-width:30em}.mw-parser-output .reflist-columns-3{column-width:25em}.mw-parser-output .reflist-columns{margin-top:0.3em}.mw-parser-output .reflist-columns ol{margin-top:0}.mw-parser-output .reflist-columns li{page-break-inside:avoid;break-inside:avoid-column}.mw-parser-output .reflist-upper-alpha{list-style-type:upper-alpha}.mw-parser-output .reflist-upper-roman{list-style-type:upper-roman}.mw-parser-output .reflist-lower-alpha{list-style-type:lower-alpha}.mw-parser-output .reflist-lower-greek{list-style-type:lower-greek}.mw-parser-output .reflist-lower-roman{list-style-type:lower-roman}

## Sources

- [Domingos, Pedro](/wiki/Pedro_Domingos) (22 September 2015). *The Master Algorithm: How the Quest for the Ultimate Learning Machine Will Remake Our World*. Basic Books. [ISBN](/wiki/ISBN_(identifier)) [978-0-465-06570-7](/wiki/Special:BookSources/978-0-465-06570-7).
- [Nilsson, Nils](/wiki/Nils_Nilsson_(researcher)) (1998). [*Artificial Intelligence: A New Synthesis*](https://archive.org/details/artificialintell0000nils). Morgan Kaufmann. [ISBN](/wiki/ISBN_(identifier)) [978-1-55860-467-4](/wiki/Special:BookSources/978-1-55860-467-4). [Archived](https://web.archive.org/web/20200726131654/https://archive.org/details/artificialintell0000nils) from the original on 26 July 2020. Retrieved 18 November 2019.
- Poole, David; [Mackworth, Alan](/wiki/Alan_Mackworth); Goebel, Randy (1998). [*Computational Intelligence: A Logical Approach*](https://archive.org/details/computationalint00pool). New York: Oxford University Press. [ISBN](/wiki/ISBN_(identifier)) [978-0-19-510270-3](/wiki/Special:BookSources/978-0-19-510270-3). [Archived](https://web.archive.org/web/20200726131436/https://archive.org/details/computationalint00pool) from the original on 26 July 2020. Retrieved 22 August 2020.
- [Russell, Stuart J.](/wiki/Stuart_J._Russell); [Norvig, Peter](/wiki/Peter_Norvig) (2003), [*Artificial Intelligence: A Modern Approach*](http://aima.cs.berkeley.edu/) (2nd ed.), Upper Saddle River, New Jersey: Prentice Hall, [ISBN](/wiki/ISBN_(identifier)) [0-13-790395-2](/wiki/Special:BookSources/0-13-790395-2).

## Further reading

.mw-parser-output .refbegin{margin-bottom:0.5em}.mw-parser-output .refbegin-hanging-indents>ul{margin-left:0}.mw-parser-output .refbegin-hanging-indents>ul>li{margin-left:0;padding-left:3.2em;text-indent:-3.2em}.mw-parser-output .refbegin-hanging-indents ul,.mw-parser-output .refbegin-hanging-indents ul li{list-style:none}@media(max-width:720px){.mw-parser-output .refbegin-hanging-indents>ul>li{padding-left:1.6em;text-indent:-1.6em}}.mw-parser-output .refbegin-columns{margin-top:0.3em}.mw-parser-output .refbegin-columns ul{margin-top:0}.mw-parser-output .refbegin-columns li{page-break-inside:avoid;break-inside:avoid-column}@media screen{.mw-parser-output .refbegin{font-size:90%}}

- [International Machine Learning Society](https://web.archive.org/web/20171230081341/http://machinelearning.org/)
- [mloss](https://mloss.org/) is an academic database of open-source machine learning software.

.mw-parser-output .navbox{box-sizing:border-box;border:1px solid #a2a9b1;width:100%;clear:both;font-size:88%;text-align:center;padding:1px;margin:1em auto 0}.mw-parser-output .navbox .navbox{margin-top:0}.mw-parser-output .navbox+.navbox,.mw-parser-output .navbox+.navbox-styles+.navbox{margin-top:-1px}.mw-parser-output .navbox-inner,.mw-parser-output .navbox-subgroup{width:100%}.mw-parser-output .navbox-group,.mw-parser-output .navbox-title,.mw-parser-output .navbox-abovebelow{padding:0.25em 1em;line-height:1.5em;text-align:center}.mw-parser-output .navbox-group{white-space:nowrap;text-align:right}.mw-parser-output .navbox,.mw-parser-output .navbox-subgroup{background-color:#fdfdfd;color:inherit}.mw-parser-output .navbox-list{line-height:1.5em;border-color:#fdfdfd}.mw-parser-output .navbox-list-with-group{text-align:left;border-left-width:2px;border-left-style:solid}.mw-parser-output tr+tr>.navbox-abovebelow,.mw-parser-output tr+tr>.navbox-group,.mw-parser-output tr+tr>.navbox-image,.mw-parser-output tr+tr>.navbox-list{border-top:2px solid #fdfdfd}.mw-parser-output .navbox-title{background-color:#ccf;color:inherit}.mw-parser-output .navbox-abovebelow,.mw-parser-output .navbox-group,.mw-parser-output .navbox-subgroup .navbox-title{background-color:#ddf;color:inherit}.mw-parser-output .navbox-subgroup .navbox-group,.mw-parser-output .navbox-subgroup .navbox-abovebelow{background-color:#e6e6ff;color:inherit}.mw-parser-output .navbox-even{background-color:#f7f7f7;color:inherit}.mw-parser-output .navbox-odd{background-color:transparent;color:inherit}.mw-parser-output .navbox .hlist td dl,.mw-parser-output .navbox .hlist td ol,.mw-parser-output .navbox .hlist td ul,.mw-parser-output .navbox td.hlist dl,.mw-parser-output .navbox td.hlist ol,.mw-parser-output .navbox td.hlist ul{padding:0.125em 0}.mw-parser-output .navbox .navbar{display:block;font-size:100%}.mw-parser-output .navbox-title .navbar{float:left;text-align:left;margin-right:0.5em}body.skin--responsive .mw-parser-output .navbox-image img{max-width:none!important}@media print{body.ns-0 .mw-parser-output .navbox{display:none!important}}

.mw-parser-output .portal-bar{font-size:88%;font-weight:bold;display:flex;justify-content:center;align-items:baseline}.mw-parser-output .portal-bar-bordered{padding:0 2em;background-color:#fdfdfd;border:1px solid #a2a9b1;clear:both;margin:1em auto 0}.mw-parser-output .portal-bar-related{font-size:100%;justify-content:flex-start}.mw-parser-output .portal-bar-unbordered{padding:0 1.7em;margin-left:0}.mw-parser-output .portal-bar-header{margin:0 1em 0 0.5em;flex:0 0 auto;min-height:24px}.mw-parser-output .portal-bar-content{display:flex;flex-flow:row wrap;flex:0 1 auto;padding:0.15em 0;column-gap:1em;align-items:baseline;margin:0;list-style:none}.mw-parser-output .portal-bar-content-related{margin:0;list-style:none}.mw-parser-output .portal-bar-item{display:inline-block;margin:0.15em 0.2em;min-height:24px;line-height:24px}@media screen and (max-width:768px){.mw-parser-output .portal-bar{font-size:88%;font-weight:bold;display:flex;flex-flow:column wrap;align-items:baseline}.mw-parser-output .portal-bar-header{text-align:center;flex:0;padding-left:0.5em;margin:0 auto}.mw-parser-output .portal-bar-related{font-size:100%;align-items:flex-start}.mw-parser-output .portal-bar-content{display:flex;flex-flow:row wrap;align-items:center;flex:0;column-gap:1em;border-top:1px solid #a2a9b1;margin:0 auto;list-style:none}.mw-parser-output .portal-bar-content-related{border-top:none;margin:0;list-style:none}}.mw-parser-output .navbox+link+.portal-bar,.mw-parser-output .navbox+style+.portal-bar,.mw-parser-output .navbox+link+.portal-bar-bordered,.mw-parser-output .navbox+style+.portal-bar-bordered,.mw-parser-output .sister-bar+link+.portal-bar,.mw-parser-output .sister-bar+style+.portal-bar,.mw-parser-output .portal-bar+.navbox-styles+.navbox,.mw-parser-output .portal-bar+.navbox-styles+.sister-bar{margin-top:-1px}

[Portals](/wiki/Wikipedia:Contents/Portals):

- [](/wiki/File:Octicons-terminal.svg) [Computer programming](/wiki/Portal:Computer_programming)
- [](/wiki/File:Nuvola_apps_edu_mathematics_blue-p.svg) [Mathematics](/wiki/Portal:Mathematics)
- [Systems science](/wiki/Portal:Systems_science)
- [](/wiki/File:Noun-technology.svg) [Technology](/wiki/Portal:Technology)

.mw-parser-output .sister-bar{display:flex;justify-content:center;align-items:baseline;font-size:88%;background-color:#fdfdfd;border:1px solid #a2a9b1;clear:both;margin:1em 0 0;padding:0 2em}.mw-parser-output .sister-bar-header{margin:0 1em 0 0.5em;padding:0.2em 0;flex:0 0 auto;min-height:24px;line-height:22px}.mw-parser-output .sister-bar-content{display:flex;flex-flow:row wrap;flex:0 1 auto;align-items:baseline;padding:0.2em 0;column-gap:1em;margin:0;list-style:none}.mw-parser-output .sister-bar-item{display:flex;align-items:baseline;margin:0.15em 0;min-height:24px;text-align:left}.mw-parser-output .sister-bar-logo{width:22px;line-height:22px;margin:0 3px 0 2px;text-align:right}.mw-parser-output .sister-bar-link{margin:0 2px 0 4px;text-align:left}@media screen and (max-width:960px){.mw-parser-output .sister-bar{flex-flow:column wrap;margin:1em auto 0}.mw-parser-output .sister-bar-header{flex:0 1}.mw-parser-output .sister-bar-content{flex:1;border-top:1px solid #a2a9b1;margin:0;list-style:none}.mw-parser-output .sister-bar-item{flex:0 0 20em;min-width:20em}}.mw-parser-output .navbox+link+.sister-bar,.mw-parser-output .navbox+style+.sister-bar,.mw-parser-output .portal-bar+link+.sister-bar,.mw-parser-output .portal-bar+style+.sister-bar,.mw-parser-output .sister-bar+.navbox-styles+.navbox,.mw-parser-output .sister-bar+.navbox-styles+.portal-bar{margin-top:-1px}@media print{body.ns-0 .mw-parser-output .sister-bar{display:none!important}}

Machine learning

at Wikipedia's

[sister projects](/wiki/Wikipedia:Wikimedia_sister_projects):

- [](/wiki/File:Wiktionary-logo-v2.svg)**[Definitions](https://en.wiktionary.org/wiki/machine_learning)** from Wiktionary
- [](/wiki/File:Commons-logo.svg)**[Media](https://commons.wikimedia.org/wiki/Category:Machine_learning)** from Commons
- [](/wiki/File:Wikiquote-logo.svg)**[Quotations](https://en.wikiquote.org/wiki/Machine_learning)** from Wikiquote
- [](/wiki/File:Wikibooks-logo.svg)**[Textbooks](https://en.wikibooks.org/wiki/Special:Search/Machine_learning)** from Wikibooks
- [](/wiki/File:Wikiversity_logo_2017.svg)**[Resources](https://en.wikiversity.org/wiki/Machine_learning)** from Wikiversity
- [](/wiki/File:Wikidata-logo.svg)**[Data](https://www.wikidata.org/wiki/Q2539)** from Wikidata

.mw-parser-output .tooltip-dotted{border-bottom:1px dotted;cursor:help}

NewPP limit report
Parsed by mw‐web.eqiad.main‐7ccf5bf5b5‐hxkns
Cached time: 20251209005939
Cache expiry: 1802
Reduced expiry: true
Complications: [vary‐revision‐sha1, show‐toc]
CPU time usage: 2.404 seconds
Real time usage: 2.799 seconds
Preprocessor visited node count: 14858/1000000
Revision size: 142548/2097152 bytes
Post‐expand include size: 553888/2097152 bytes
Template argument size: 7962/2097152 bytes
Highest expansion depth: 21/100
Expensive parser function count: 42/500
Unstrip recursion depth: 1/20
Unstrip post‐expand size: 727811/5000000 bytes
Lua time usage: 1.674/10.000 seconds
Lua memory usage: 30581086/52428800 bytes
Number of Wikibase entities loaded: 1/500

Transclusion expansion time report (%,ms,calls,template)
100.00% 2374.605      1 -total
 48.33% 1147.669      1 Template:Reflist
 17.49%  415.320     58 Template:Cite_journal
  8.33%  197.734      7 Template:Annotated_link
  7.77%  184.573     28 Template:Cite_book
  7.65%  181.727     34 Template:Cite_web
  5.35%  126.928      2 Template:Excerpt
  4.69%  111.283      2 Template:Sfn
  4.66%  110.561     21 Template:Cite_news
  4.30%  102.039      2 Template:Refn

Saved in parser cache with key enwiki:pcache:233488:|#|:idhash:canonical and timestamp 20251209005939 and revision id 1326373574. Rendering was triggered because: page_view
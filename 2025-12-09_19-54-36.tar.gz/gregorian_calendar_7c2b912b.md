<!-- title: Gregorian Calendar -->
<-- url: https://en.wikipedia.org/wiki/Gregorian_calendar -->

# Gregorian calendar

[](/wiki/Wikipedia:Protection_policy#semi)
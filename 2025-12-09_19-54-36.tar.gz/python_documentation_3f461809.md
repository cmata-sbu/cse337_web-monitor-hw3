<!-- title: Python Documentation -->
<-- url: https://en.wikipedia.org/wiki/Python_(programming_language) -->

# Python (programming language)

[](/wiki/Wikipedia:Protection_policy#semi)
<!-- title: Data Science -->
<-- url: https://en.wikipedia.org/wiki/Data_science -->

# Data science

Field of study to extract knowledge from data

.mw-parser-output .hatnote{font-style:italic}.mw-parser-output div.hatnote{padding-left:1.6em;margin-bottom:0.5em}.mw-parser-output .hatnote i{font-style:normal}.mw-parser-output .hatnote+link+.hatnote{margin-top:-0.5em}@media print{body.ns-0 .mw-parser-output .hatnote{display:none!important}}

**Data science** is an [interdisciplinary](/wiki/Interdisciplinary) academic field that uses [statistics](/wiki/Statistics), [scientific computing](/wiki/Scientific_computing), [scientific methods](/wiki/Scientific_method), processing, [scientific visualization](/wiki/Scientific_visualization), [algorithms](/wiki/Algorithm) and systems to extract or extrapolate [knowledge](/wiki/Knowledge) from potentially noisy, [structured](/wiki/Data_model), or [unstructured data](/wiki/Unstructured_data).

Data science also integrates domain knowledge from the underlying application domain (e.g., natural sciences, information technology, and medicine). Data science is multifaceted and can be described as a science, a research paradigm, a research method, a discipline, a workflow, and a profession.

Data science is "a concept to unify [statistics](/wiki/Statistics), [data analysis](/wiki/Data_analysis), [informatics](/wiki/Informatics), and their related [methods](/wiki/Scientific_method)" to "understand and analyze actual [phenomena](/wiki/Phenomena)" with [data](/wiki/Data). It uses techniques and theories drawn from many fields within the context of [mathematics](/wiki/Mathematics), statistics, [computer science](/wiki/Computer_science), [information science](/wiki/Information_science), and [domain knowledge](/wiki/Domain_knowledge). However, data science is different from [computer science](/wiki/Computer_science) and information science. [Turing Award](/wiki/Turing_Award) winner [Jim Gray](/wiki/Jim_Gray_(computer_scientist)) imagined data science as a "fourth paradigm" of science ([empirical](/wiki/Empirical_research), [theoretical](/wiki/Basic_research), [computational](/wiki/Computational_science), and now data-driven) and asserted that "everything about science is changing because of the impact of [information technology](/wiki/Information_technology)" and the [data deluge](/wiki/Information_explosion).

Data science is often described as a multidisciplinary field because it draws on techniques from diverse areas, such as computer science, statistics, information science, and other subject-specific disciplines. Some researchers say that the combination of the different fields is similar to how information science was decades ago (Mayernik, 2023). These similarities help us understand how data science became its own field of study.

A **data scientist** is a professional who creates programming code and combines it with statistical knowledge to summarize data.

## Foundations

Data science is an [interdisciplinary](/wiki/Interdisciplinarity) [field](/wiki/Academic_discipline) focused on [extracting knowledge](/wiki/Knowledge_extraction) from typically [large](/wiki/Big_data) [data sets](/wiki/Data_set) and applying the knowledge from that data to solve problems in other application domains. The field encompasses preparing data for analysis, formulating data science problems, [analyzing](/wiki/Analysis) data, and summarizing these findings. As such, it incorporates skills from computer science, mathematics, [data visualization](/wiki/Data_visualization), [graphic design](/wiki/Graphic_design), [communication](/wiki/Communication), and [business](/wiki/Business).

[Vasant Dhar](/wiki/Vasant_Dhar) writes that statistics emphasizes quantitative data and description. In contrast, data science deals with quantitative and qualitative data (e.g., from images, text, sensors, transactions, customer information, etc.) and emphasizes prediction and action. [Andrew Gelman](/wiki/Andrew_Gelman) of [Columbia University](/wiki/Columbia_University) has described statistics as a non-essential part of data science. Stanford professor [David Donoho](/wiki/David_Donoho) writes that data science is not distinguished from statistics by the size of datasets or use of computing and that many graduate programs misleadingly advertise their analytics and statistics training as the essence of a data-science program. He describes data science as an applied field growing out of traditional statistics.

## Etymology

### Early usage

In 1962, [John Tukey](/wiki/John_Tukey) described a field he called "[data analysis](/wiki/Data_analysis)", which resembles modern data science. In 1985, in a lecture given to the Chinese Academy of Sciences in Beijing, [C. F. Jeff Wu](/wiki/C._F._Jeff_Wu) used the term "data science" for the first time as an alternative name for statistics. Later, attendees at a 1992 statistics symposium at the [University of Montpellier  II](/wiki/Montpellier_2_University) acknowledged the emergence of a new discipline focused on data of various origins and forms, combining established concepts and principles of statistics and data analysis with computing.

The term "data science" has been traced back to 1974, when [Peter Naur](/wiki/Peter_Naur) proposed it as an alternative name to computer science. In his 1974 book Concise Survey of Computer Methods, Peter Naur proposed using the term ‘data science’ rather than ‘computer science’ to reflect the growing emphasis on data-driven methods In 1996, the International Federation of Classification Societies became the first conference to specifically feature data science as a topic. However, the definition was still in flux. After the 1985 lecture at the Chinese Academy of Sciences in Beijing, in 1997 [C. F. Jeff Wu](/wiki/C._F._Jeff_Wu) again suggested that statistics should be renamed data science. He reasoned that a new name would help statistics shed inaccurate stereotypes, such as being synonymous with accounting or limited to describing data. In 1998, Hayashi Chikio argued for data science as a new, interdisciplinary concept, with three aspects: data design, collection, and analysis.

### Modern usage

In 2012, technologists [Thomas H. Davenport](/wiki/Thomas_H._Davenport) and [DJ Patil](/wiki/DJ_Patil) declared "Data Scientist: The Sexiest Job of the 21st Century", a catchphrase that was picked up even by major-city newspapers like the [New York Times](/wiki/New_York_Times) and the [Boston Globe](/wiki/Boston_Globe). A decade later, they reaffirmed it, stating that "the job is more in demand than ever with employers".

The modern conception of data science as an independent discipline is sometimes attributed to [William S. Cleveland](/wiki/William_S._Cleveland). In 2014, the [American Statistical Association](/wiki/American_Statistical_Association)'s Section on Statistical Learning and Data Mining changed its name to the Section on Statistical Learning and Data Science, reflecting the ascendant popularity of data science.

Over the last few years, many colleges have begun to create more structured undergraduate programs in data science. According to a report by the National Academies, strong programs typically include training in statistics, computing, ethics, and communication, as well as hands-on work in a specific field (National Academies of Sciences, Engineering, and Medicine, 2018). As schools try to prepare students for jobs that use data, these practices become more common.

The professional title of "data scientist" has been attributed to [DJ Patil](/wiki/DJ_Patil) and [Jeff Hammerbacher](/wiki/Jeff_Hammerbacher) in 2008. Though it was used by the [National Science Board](/wiki/National_Science_Board) in their 2005 report "Long-Lived Digital Data Collections: Enabling Research and Education in the 21st Century", it referred broadly to any key role in managing a digital [data collection](/wiki/Data_collection).

## Data science and data analysis

In data science, **data analysis** is the process of inspecting, cleaning, transforming, and modelling data to discover useful information, draw conclusions, and support decision-making. It includes **exploratory data analysis** (EDA), which uses graphics and descriptive statistics to explore patterns and generate hypotheses, and **confirmatory data analysis**, which applies statistical inference to test hypotheses and quantify uncertainty.

Typical activities comprise:

- data collection and integration;
- data cleaning and preparation (handling missing values, outliers, encoding, normalisation);
- feature engineering and selection;
- visualisation and descriptive statistics;
- fitting and evaluating statistical or machine-learning models;
- communicating results and ensuring reproducibility (e.g., reports, notebooks, and dashboards).

Lifecycle frameworks such as [CRISP-DM](/wiki/CRISP-DM) describe these steps from business understanding through deployment and monitoring.

Data science involves working with larger datasets that often require advanced computational and statistical methods to analyze. Data scientists often work with [unstructured data](/wiki/Unstructured_data) such as text or images and use [machine learning](/wiki/Machine_learning) algorithms to build predictive models. Data science often uses [statistical analysis](/wiki/Statistical_analysis), [data preprocessing](/wiki/Data_preprocessing), and [supervised learning](/wiki/Supervised_learning).

Recent studies indicate that AI is moving towards data-centric approaches, focusing on the quality of datasets rather than just improving AI models. This trend focuses on improving system performance by cleaning, refining, and labeling data (Bhatt et al., 2024). As AI systems grow larger, the data-centric view has become increasingly important.

## Cloud computing for data science

[Cloud computing](/wiki/Cloud_computing) can offer access to large amounts of computational power and [storage](/wiki/Data_storage). In [big data](/wiki/Big_data), where volumes of information are continually generated and processed, these platforms can be used to handle complex and resource-intensive analytical tasks.

Some distributed computing frameworks are designed to handle big data workloads. These frameworks can enable data scientists to process and analyze large datasets in parallel, which can reduce processing times.

## Ethical consideration in data science

Data science involves collecting, processing, and analyzing data which often includes personal and sensitive information. Ethical concerns include potential privacy violations, bias perpetuation, and negative societal impacts.

Ethics education in data science has grown to encompass both technical principles and more expansive philosophical questions. Research indicates that data science ethics courses are increasingly integrating human-centric topics, including fairness, accountability, and responsible decision-making, thereby connecting them to enduring discussions in moral and political philosophy (Colando & Hardin, 2024). The goal of this method is to help students understand how data-driven technologies affect society.

Machine learning models can amplify existing biases present in training data, leading to discriminatory or unfair outcomes.Another area of data science that is growing is the push for better ways to cite data. Citing datasets makes it easier for other researchers to understand what data was used and for studies to be repeated (Lafia et al., 2023). These practices give the people who collect and manage data the credit they deserve, which is becoming more important in modern research.

## See also

.mw-parser-output .side-box{margin:4px 0;box-sizing:border-box;border:1px solid #aaa;font-size:88%;line-height:1.25em;background-color:var(--background-color-interactive-subtle,#f8f9fa);color:inherit;display:flow-root}.mw-parser-output .infobox .side-box{font-size:100%}.mw-parser-output .side-box-abovebelow,.mw-parser-output .side-box-text{padding:0.25em 0.9em}.mw-parser-output .side-box-image{padding:2px 0 2px 0.9em;text-align:center}.mw-parser-output .side-box-imageright{padding:2px 0.9em 2px 0;text-align:center}@media(min-width:500px){.mw-parser-output .side-box-flex{display:flex;align-items:center}.mw-parser-output .side-box-text{flex:1;min-width:0}}@media(min-width:640px){.mw-parser-output .side-box{width:238px}.mw-parser-output .side-box-right{clear:right;float:right;margin-left:1em}.mw-parser-output .side-box-left{margin-right:1em}}

@media print{body.ns-0 .mw-parser-output .sistersitebox{display:none!important}}@media screen{html.skin-theme-clientpref-night .mw-parser-output .sistersitebox img[src*="Wiktionary-logo-en-v2.svg"]{filter:invert(1)brightness(55%)contrast(250%)hue-rotate(180deg)}}@media screen and (prefers-color-scheme:dark){html.skin-theme-clientpref-os .mw-parser-output .sistersitebox img[src*="Wiktionary-logo-en-v2.svg"]{filter:invert(1)brightness(55%)contrast(250%)hue-rotate(180deg)}}

.mw-parser-output .plainlist ol,.mw-parser-output .plainlist ul{line-height:inherit;list-style:none;margin:0;padding:0}.mw-parser-output .plainlist ol li,.mw-parser-output .plainlist ul li{margin-bottom:0}

[](/wiki/File:Wikibooks-logo-en-noslogan.svg)Wikibooks has a book on the topic of:

[Data Science: An Introduction](https://en.wikibooks.org/wiki/Data_Science:_An_Introduction)- [Python (programming language)](/wiki/Python_(programming_language))
- [R (programming language)](/wiki/R_(programming_language))
- [Data engineering](/wiki/Data_engineering)
- [Big data](/wiki/Big_data)
- [Machine learning](/wiki/Machine_learning)
- [Artificial intelligence](/wiki/Artificial_intelligence)
- [Bioinformatics](/wiki/Bioinformatics)
- [Astroinformatics](/wiki/Astroinformatics)
- [Topological data analysis](/wiki/Topological_data_analysis)
- [List of data science journals](/wiki/List_of_data_science_journals)
- [List of data science software](/wiki/List_of_data_science_software)
- [List of open-source data science software](/wiki/List_of_free_and_open-source_software_packages#Data_science)
- [Data science notebook software](/wiki/Notebook_interface#Notable_examples)

## References

.mw-parser-output .reflist{margin-bottom:0.5em;list-style-type:decimal}@media screen{.mw-parser-output .reflist{font-size:90%}}.mw-parser-output .reflist .references{font-size:100%;margin-bottom:0;list-style-type:inherit}.mw-parser-output .reflist-columns-2{column-width:30em}.mw-parser-output .reflist-columns-3{column-width:25em}.mw-parser-output .reflist-columns{margin-top:0.3em}.mw-parser-output .reflist-columns ol{margin-top:0}.mw-parser-output .reflist-columns li{page-break-inside:avoid;break-inside:avoid-column}.mw-parser-output .reflist-upper-alpha{list-style-type:upper-alpha}.mw-parser-output .reflist-upper-roman{list-style-type:upper-roman}.mw-parser-output .reflist-lower-alpha{list-style-type:lower-alpha}.mw-parser-output .reflist-lower-greek{list-style-type:lower-greek}.mw-parser-output .reflist-lower-roman{list-style-type:lower-roman}

.mw-parser-output .hlist dl,.mw-parser-output .hlist ol,.mw-parser-output .hlist ul{margin:0;padding:0}.mw-parser-output .hlist dd,.mw-parser-output .hlist dt,.mw-parser-output .hlist li{margin:0;display:inline}.mw-parser-output .hlist.inline,.mw-parser-output .hlist.inline dl,.mw-parser-output .hlist.inline ol,.mw-parser-output .hlist.inline ul,.mw-parser-output .hlist dl dl,.mw-parser-output .hlist dl ol,.mw-parser-output .hlist dl ul,.mw-parser-output .hlist ol dl,.mw-parser-output .hlist ol ol,.mw-parser-output .hlist ol ul,.mw-parser-output .hlist ul dl,.mw-parser-output .hlist ul ol,.mw-parser-output .hlist ul ul{display:inline}.mw-parser-output .hlist .mw-empty-li{display:none}.mw-parser-output .hlist dt::after{content:": "}.mw-parser-output .hlist dd::after,.mw-parser-output .hlist li::after{content:" · ";font-weight:bold}.mw-parser-output .hlist dd:last-child::after,.mw-parser-output .hlist dt:last-child::after,.mw-parser-output .hlist li:last-child::after{content:none}.mw-parser-output .hlist dd dd:first-child::before,.mw-parser-output .hlist dd dt:first-child::before,.mw-parser-output .hlist dd li:first-child::before,.mw-parser-output .hlist dt dd:first-child::before,.mw-parser-output .hlist dt dt:first-child::before,.mw-parser-output .hlist dt li:first-child::before,.mw-parser-output .hlist li dd:first-child::before,.mw-parser-output .hlist li dt:first-child::before,.mw-parser-output .hlist li li:first-child::before{content:" (";font-weight:normal}.mw-parser-output .hlist dd dd:last-child::after,.mw-parser-output .hlist dd dt:last-child::after,.mw-parser-output .hlist dd li:last-child::after,.mw-parser-output .hlist dt dd:last-child::after,.mw-parser-output .hlist dt dt:last-child::after,.mw-parser-output .hlist dt li:last-child::after,.mw-parser-output .hlist li dd:last-child::after,.mw-parser-output .hlist li dt:last-child::after,.mw-parser-output .hlist li li:last-child::after{content:")";font-weight:normal}.mw-parser-output .hlist ol{counter-reset:listitem}.mw-parser-output .hlist ol>li{counter-increment:listitem}.mw-parser-output .hlist ol>li::before{content:" "counter(listitem)"\a0 "}.mw-parser-output .hlist dd ol>li:first-child::before,.mw-parser-output .hlist dt ol>li:first-child::before,.mw-parser-output .hlist li ol>li:first-child::before{content:" ("counter(listitem)"\a0 "}

.mw-parser-output .navbox{box-sizing:border-box;border:1px solid #a2a9b1;width:100%;clear:both;font-size:88%;text-align:center;padding:1px;margin:1em auto 0}.mw-parser-output .navbox .navbox{margin-top:0}.mw-parser-output .navbox+.navbox,.mw-parser-output .navbox+.navbox-styles+.navbox{margin-top:-1px}.mw-parser-output .navbox-inner,.mw-parser-output .navbox-subgroup{width:100%}.mw-parser-output .navbox-group,.mw-parser-output .navbox-title,.mw-parser-output .navbox-abovebelow{padding:0.25em 1em;line-height:1.5em;text-align:center}.mw-parser-output .navbox-group{white-space:nowrap;text-align:right}.mw-parser-output .navbox,.mw-parser-output .navbox-subgroup{background-color:#fdfdfd;color:inherit}.mw-parser-output .navbox-list{line-height:1.5em;border-color:#fdfdfd}.mw-parser-output .navbox-list-with-group{text-align:left;border-left-width:2px;border-left-style:solid}.mw-parser-output tr+tr>.navbox-abovebelow,.mw-parser-output tr+tr>.navbox-group,.mw-parser-output tr+tr>.navbox-image,.mw-parser-output tr+tr>.navbox-list{border-top:2px solid #fdfdfd}.mw-parser-output .navbox-title{background-color:#ccf;color:inherit}.mw-parser-output .navbox-abovebelow,.mw-parser-output .navbox-group,.mw-parser-output .navbox-subgroup .navbox-title{background-color:#ddf;color:inherit}.mw-parser-output .navbox-subgroup .navbox-group,.mw-parser-output .navbox-subgroup .navbox-abovebelow{background-color:#e6e6ff;color:inherit}.mw-parser-output .navbox-even{background-color:#f7f7f7;color:inherit}.mw-parser-output .navbox-odd{background-color:transparent;color:inherit}.mw-parser-output .navbox .hlist td dl,.mw-parser-output .navbox .hlist td ol,.mw-parser-output .navbox .hlist td ul,.mw-parser-output .navbox td.hlist dl,.mw-parser-output .navbox td.hlist ol,.mw-parser-output .navbox td.hlist ul{padding:0.125em 0}.mw-parser-output .navbox .navbar{display:block;font-size:100%}.mw-parser-output .navbox-title .navbar{float:left;text-align:left;margin-right:0.5em}body.skin--responsive .mw-parser-output .navbox-image img{max-width:none!important}@media print{body.ns-0 .mw-parser-output .navbox{display:none!important}}

NewPP limit report
Parsed by mw‐api‐ext.eqiad.main‐7b7647d655‐79msf
Cached time: 20251208174936
Cache expiry: 22234
Reduced expiry: true
Complications: [vary‐revision‐sha1, show‐toc]
CPU time usage: 0.719 seconds
Real time usage: 0.858 seconds
Preprocessor visited node count: 2900/1000000
Revision size: 26990/2097152 bytes
Post‐expand include size: 108059/2097152 bytes
Template argument size: 1099/2097152 bytes
Highest expansion depth: 13/100
Expensive parser function count: 5/500
Unstrip recursion depth: 1/20
Unstrip post‐expand size: 183696/5000000 bytes
Lua time usage: 0.506/10.000 seconds
Lua memory usage: 8285095/52428800 bytes
Number of Wikibase entities loaded: 2/500

Transclusion expansion time report (%,ms,calls,template)
100.00%  764.243      1 -total
 63.94%  488.638      1 Template:Reflist
 29.52%  225.579     20 Template:Cite_journal
 11.90%   90.980      1 Template:Short_description
 10.96%   83.727      1 Template:Data
 10.93%   83.529      1 Template:Cite_Q
 10.69%   81.663      1 Template:Navbox
  8.21%   62.759     10 Template:Cite_book
  7.09%   54.215      2 Template:Pagetype
  4.49%   34.295      1 Template:Wikibooks

Saved in parser cache with key enwiki:pcache:35458904:|#|:idhash:canonical and timestamp 20251208174936 and revision id 1324914564. Rendering was triggered because: unknown